import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    'preview-chat-ad45caa9-e948-4039-b7df-8ad04aa3ba94.space-z.ai',
  ],
};

export default nextConfig;
