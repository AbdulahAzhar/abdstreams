import { NextResponse } from 'next/server';

interface StreamItem {
  id: number;
  label: string;
  url: string;
  drmScheme?: string;
  kid?: string;
  key?: string;
  type: 'dash' | 'hls';
}

interface StreamGroup {
  title: string;
  streams: StreamItem[];
}

function parseStreamLineWithLabel(line: string, label: string | null, linkId: { v: number }): StreamItem | null {
  const trimmed = line.trim();

  // Decode URL-encoded characters
  const decoded = trimmed.replace(/%7C/g, '|').replace(/%3A/g, ':').replace(/%26/g, '&');

  // The line starts with a URL. Extract URL and DRM params.
  let url = decoded;
  let kid: string | undefined;
  let key: string | undefined;
  let drmScheme: string | undefined;

  // Check for DRM params after pipe
  const drmMatch = url.match(/^(.+?)\|drmScheme=([^&]+)&drmLicense=([^:]+):([^\s]+)$/i);
  if (drmMatch) {
    url = drmMatch[1];
    drmScheme = drmMatch[2];
    kid = drmMatch[3];
    key = drmMatch[4];
  }

  // Validate: must look like a stream URL (.mpd, .m3u8) or have DRM params
  if (!url.match(/\.(mpd|m3u8)/i) && !drmScheme) return null;

  linkId.v++;
  return {
    id: linkId.v,
    label: label && label.trim().length > 0 ? label.trim() : `Stream ${linkId.v}`,
    url,
    drmScheme,
    kid,
    key,
    type: url.includes('.m3u8') ? 'hls' : 'dash',
  };
}

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const response = await fetch('https://t.me/s/teztstreams', {
      cache: 'no-store',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      },
    });

    if (!response.ok) {
      return NextResponse.json({ groups: [] }, { status: 500 });
    }

    const rawHtml = await response.text();

    // Decode HTML entities
    const text = rawHtml
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ');

    // Extract all message text divs
    const messageRegex =
      /<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;
    const groups: StreamGroup[] = [];
    const linkId = { v: 0 };

    let messageMatch;
    while ((messageMatch = messageRegex.exec(text)) !== null) {
      const rawContent = messageMatch[1];

      // Convert <br/> to newlines, then strip remaining HTML tags
      const plainText = rawContent
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .trim();

      if (!plainText) continue;

      // Split into lines
      const lines = plainText
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l.length > 0);

      if (lines.length === 0) continue;

      // First line is the title (skip generic service messages)
      const title = lines[0];
      if (/^channel created$/i.test(title)) continue;

      // Parse remaining lines for stream links
      // Track previous non-URL line as potential label (Telegram now puts label and URL on separate lines)
      const streams: StreamItem[] = [];
      let pendingLabel: string | null = null;

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        const isUrlLine = /^https?:\/\//i.test(line);

        if (!isUrlLine) {
          // This line is not a URL — remember it as a potential label for the next URL line
          pendingLabel = line;
          continue;
        }

        // This is a URL line — try to parse it with pendingLabel as context
        const parsed = parseStreamLineWithLabel(line, pendingLabel, linkId);
        if (parsed) {
          streams.push(parsed);
        }
        pendingLabel = null;
      }

      if (streams.length > 0) {
        groups.push({ title, streams });
      }
    }

    return NextResponse.json({ groups }, {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
    });
  } catch (error) {
    console.error('Error fetching streams:', error);
    return NextResponse.json({ groups: [] }, { status: 500 });
  }
}
