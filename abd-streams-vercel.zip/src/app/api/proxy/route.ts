import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const url = request.nextUrl.searchParams.get('url');

  if (!url) {
    return NextResponse.json({ error: 'Missing url parameter' }, { status: 400 });
  }

  // Validate URL format
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    return NextResponse.json({ error: 'Invalid URL' }, { status: 400 });
  }

  // Only allow http/https
  if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
    return NextResponse.json({ error: 'Only HTTP(S) URLs allowed' }, { status: 400 });
  }

  try {
    const headers: Record<string, string> = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      Accept: '*/*',
    };

    // For HLS manifests, rewrite segment URLs to go through our proxy
    const response = await fetch(url, {
      headers,
      redirect: 'follow',
    });

    if (!response.ok) {
      return new NextResponse(`Upstream error: ${response.status}`, {
        status: response.status,
        headers: {
          'Access-Control-Allow-Origin': '*',
        },
      });
    }

    const contentType = response.headers.get('content-type') || '';
    const body = await response.arrayBuffer();

    // For HLS manifests, rewrite relative URLs to absolute proxy URLs
    if (
      contentType.includes('mpegurl') ||
      contentType.includes('text/plain') ||
      url.endsWith('.m3u8')
    ) {
      const text = new TextDecoder().decode(body);
      const baseUrl = url.substring(0, url.lastIndexOf('/') + 1);

      // Rewrite relative segment URLs and key URLs to go through /api/proxy
      const rewritten = text.replace(
        /^(?!#)(?!http)([^\s?#]+)$/gm,
        (match) => {
          // Skip empty lines and comments that might be matched
          if (match.startsWith('#')) return match;
          return `/api/proxy?url=${encodeURIComponent(baseUrl + match)}`;
        }
      ).replace(
        /^(?!#)(?!\/api\/)(https?:\/\/[^\s?#]+)$/gm,
        (match) => {
          return `/api/proxy?url=${encodeURIComponent(match)}`;
        }
      );

      return new NextResponse(rewritten, {
        headers: {
          'Content-Type': 'application/vnd.apple.mpegurl',
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache, no-store',
        },
      });
    }

    // For DASH manifests and other content, pass through
    return new NextResponse(body, {
      headers: {
        'Content-Type': contentType || 'application/octet-stream',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-cache, no-store',
      },
    });
  } catch (error: any) {
    console.error('Proxy error:', error.message);
    return NextResponse.json(
      { error: 'Failed to fetch upstream resource' },
      { status: 502 }
    );
  }
}
