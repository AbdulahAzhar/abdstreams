import { NextResponse } from 'next/server';
import { NextRequest } from 'next/server';

interface M3UStream {
  id: number;
  label: string;
  url: string;
  logo?: string;
  group?: string;
  drmScheme?: string;
  kid?: string;
  key?: string;
  type: 'dash' | 'hls';
}

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const m3uUrl = searchParams.get('url');

  if (!m3uUrl) {
    return NextResponse.json({ streams: [], error: 'Missing url parameter' }, { status: 400 });
  }

  try {
    const response = await fetch(m3uUrl, {
      cache: 'no-store',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        Accept: '*/*',
      },
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      return NextResponse.json({ streams: [], error: `Failed to fetch M3U: ${response.status}` }, { status: 502 });
    }

    const m3uText = await response.text();
    const streams = parseM3U(m3uText);

    return NextResponse.json({ streams, title: extractTitleFromUrl(m3uUrl) }, {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
    });
  } catch (error) {
    console.error('Error fetching M3U:', error);
    const msg = error instanceof Error && error.name === 'TimeoutError'
      ? 'M3U fetch timed out'
      : 'Failed to fetch M3U';
    return NextResponse.json({ streams: [], error: msg }, { status: 500 });
  }
}

function extractTitleFromUrl(url: string): string {
  try {
    const pathname = new URL(url).pathname;
    const filename = pathname.split('/').pop() || '';
    return filename.replace(/\.m3u.*$/i, '').replace(/[-_]/g, ' ').toUpperCase();
  } catch {
    return 'CHANNELS';
  }
}

function parseM3U(content: string): M3UStream[] {
  const lines = content.split('\n').map((l) => l.trim()).filter(Boolean);
  const streams: M3UStream[] = [];
  let streamId = 0;
  let currentLabel = '';
  let currentLogo = '';
  let currentGroup = '';
  let currentKid = '';
  let currentKey = '';
  let currentDrmScheme: string | undefined;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Parse EXTINF line for channel name and attributes
    if (line.startsWith('#EXTINF')) {
      currentLabel = '';
      currentLogo = '';
      currentGroup = '';

      // Extract tvg-name first
      const nameMatch = line.match(/tvg-name="([^"]*)"/i);
      const nameMatch2 = line.match(/tvg-name="([^"]*)"/i);

      // Extract the display name after the last comma
      const commaIdx = line.lastIndexOf(',');
      if (commaIdx !== -1) {
        currentLabel = line.substring(commaIdx + 1).trim();
      }

      // Extract logo
      const logoMatch = line.match(/tvg-logo="([^"]*)"/i);
      if (logoMatch) currentLogo = logoMatch[1];

      // Extract group-title
      const groupMatch = line.match(/group-title="([^"]*)"/i);
      if (groupMatch) currentGroup = groupMatch[1];

      continue;
    }

    // Parse KODIPROP for DRM keys
    if (line.startsWith('#KODIPROP:')) {
      const licenseMatch = line.match(/license_key=([^:\s]+):([^\s]+)/i);
      if (licenseMatch) {
        currentKid = licenseMatch[1];
        currentKey = licenseMatch[2];
        currentDrmScheme = 'clearkey';
      }
      const drmTypeMatch = line.match(/license_type=(\w+)/i);
      if (drmTypeMatch && drmTypeMatch[1].toLowerCase() !== 'clearkey') {
        currentDrmScheme = drmTypeMatch[1].toLowerCase();
      }
      continue;
    }

    // Skip other directives
    if (line.startsWith('#')) continue;

    // This should be a stream URL
    if (/^https?:\/\//i.test(line) || /\.(mpd|m3u8)/i.test(line)) {
      const url = line.trim();
      if (!url) continue;

      streamId++;
      streams.push({
        id: streamId,
        label: currentLabel || `Channel ${streamId}`,
        url,
        logo: currentLogo || undefined,
        group: currentGroup || undefined,
        drmScheme: currentDrmScheme,
        kid: currentKid || undefined,
        key: currentKey || undefined,
        type: /\.m3u8/i.test(url) ? 'hls' : 'dash',
      });

      // Reset for next entry
      currentLabel = '';
      currentLogo = '';
      currentGroup = '';
      currentKid = '';
      currentKey = '';
      currentDrmScheme = undefined;
    }
  }

  return streams;
}
