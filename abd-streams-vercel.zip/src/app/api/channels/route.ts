import { NextResponse } from 'next/server';

interface ChannelSource {
  id: string;
  title: string;
  m3uUrl: string;
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const response = await fetch('https://t.me/s/teztstreams', {
      cache: 'no-store',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      },
    });

    if (!response.ok) {
      return NextResponse.json({ channels: [] }, { status: 500 });
    }

    const rawHtml = await response.text();

    const text = rawHtml
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ');

    const messageRegex =
      /<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;

    let messageMatch;
    while ((messageMatch = messageRegex.exec(text)) !== null) {
      const rawContent = messageMatch[1];
      const plainText = rawContent
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<[^>]+>/g, '')
        .trim();

      if (!plainText) continue;

      const lines = plainText
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l.length > 0);

      if (lines.length === 0) continue;

      const title = lines[0];
      if (title.toUpperCase() !== 'CHANNELS') continue;

      // Parse channel title + M3U URL pairs from remaining lines
      const channels: ChannelSource[] = [];
      let pendingTitle: string | null = null;

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        const isUrl = /^https?:\/\//i.test(line);

        if (!isUrl) {
          pendingTitle = line;
          continue;
        }

        if (pendingTitle && isUrl) {
          channels.push({
            id: slugify(pendingTitle),
            title: pendingTitle.toUpperCase(),
            m3uUrl: line,
          });
        }
        pendingTitle = null;
      }

      if (channels.length > 0) {
        return NextResponse.json({ channels }, {
          headers: {
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0',
          },
        });
      }
    }

    return NextResponse.json({ channels: [] });
  } catch (error) {
    console.error('Error fetching channels:', error);
    return NextResponse.json({ channels: [] }, { status: 500 });
  }
}
