'use client';
// v53 — Channels section: orange color, consistent cards, no M3U tags

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Play,
  RefreshCw,
  AlertCircle,
  Radio,
  Loader2,
  X,
  ChevronRight,
  MonitorPlay,
  Flame,
  Tv,
  ArrowLeft,
} from 'lucide-react';
import CustomPlayer, { CustomPlayerHandle } from '@/components/CustomPlayer';

interface StreamItem {
  id: number;
  label: string;
  url: string;
  logo?: string;
  group?: string;
  drmScheme?: string;
  kid?: string;
  key?: string;
  type: 'dash' | 'hls';
}

interface StreamGroup {
  title: string;
  streams: StreamItem[];
}

interface ChannelSource {
  id: string;
  title: string;
  m3uUrl: string;
}

// Stream fetching moved to server-side /api/streams — no CORS proxy needed

export default function Home() {
  const [groups, setGroups] = useState<StreamGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeStream, setActiveStream] = useState<StreamItem | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [playerError, setPlayerError] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string | null>('');
  const playerRef = useRef<CustomPlayerHandle>(null);
  const filterScrollRef = useRef<HTMLDivElement>(null);

  // Channel states
  const [channelSources, setChannelSources] = useState<ChannelSource[]>([]);
  const [channelSourcesLoading, setChannelSourcesLoading] = useState(false);
  const [activeChannelSource, setActiveChannelSource] = useState<ChannelSource | null>(null);
  const [channelStreams, setChannelStreams] = useState<StreamItem[]>([]);
  const [channelStreamsLoading, setChannelStreamsLoading] = useState(false);

  const fetchStreams = useCallback(async () => {
    setLoading(true);
    setError(null);
    setActiveFilter('');
    try {
      const res = await fetch('/api/streams', { cache: 'no-store' });
      if (!res.ok) {
        setError('Unable to load streams. Please try again.');
        setGroups([]);
        return;
      }
      const data = await res.json();
      if (!data.groups || data.groups.length === 0) {
        setError('Unable to load streams. Please try again.');
        setGroups([]);
      } else {
        setGroups(data.groups);
      }
    } catch {
      setError('Unable to load streams. Check your internet connection and try again.');
      setGroups([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchChannels = useCallback(async () => {
    setChannelSourcesLoading(true);
    try {
      const res = await fetch('/api/channels', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.channels && data.channels.length > 0) {
          setChannelSources(data.channels);
        }
      }
    } catch {
      // Silently fail — channels are optional
    } finally {
      setChannelSourcesLoading(false);
    }
  }, []);

  const handleChannelClick = useCallback(async (channel: ChannelSource) => {
    setActiveChannelSource(channel);
    setChannelStreamsLoading(true);
    setChannelStreams([]);
    try {
      const encodedUrl = encodeURIComponent(channel.m3uUrl);
      const res = await fetch(`/api/channels/streams?url=${encodedUrl}`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.streams && data.streams.length > 0) {
          setChannelStreams(data.streams);
        }
      }
    } catch {
      // Silently fail
    } finally {
      setChannelStreamsLoading(false);
    }
  }, []);

  const handleBackToChannels = useCallback(() => {
    setActiveChannelSource(null);
    setChannelStreams([]);
  }, []);

  useEffect(() => {
    fetchStreams();
    fetchChannels();
  }, [fetchStreams, fetchChannels]);

  const handleStreamClick = (stream: StreamItem) => {
    if (playerRef.current) {
      try { playerRef.current.destroy(); } catch {}
    }
    setPlayerError(null);
    setActiveStream(stream);
    setActiveId(stream.id);
  };

  const closePlayer = () => {
    if (playerRef.current) {
      try { playerRef.current.destroy(); } catch {}
    }
    setActiveStream(null);
    setPlayerError(null);
    setActiveId(null);
  };

  const handlePlayerError = useCallback((msg: string) => {
    setPlayerError(msg);
  }, []);

  const getStreamUseProxy = useCallback((stream: StreamItem) => {
    // Channel streams don't need proxy by default (Akamai/dice-live URLs)
    if (activeFilter === '__CHANNELS__') return false;

    const label = (stream.label || '').toUpperCase();
    const url = (stream.url || '').toLowerCase();

    if (label.includes('UK') || label.includes('SKY SPORTS UK')) return true;
    if (url.includes('rutube.ru')) return true;

    for (const group of groups) {
      if (group.streams.some(s => s.id === stream.id)) {
        const title = (group.title || '').toUpperCase();
        if (title.includes('UK') || title.includes('SKY SPORTS UK')) return true;
      }
    }

    return false;
  }, [groups, activeFilter]);

  const groupColors = [
    '#14b6e5',
    '#f97316',
    '#22c55e',
    '#ef4444',
    '#a855f7',
    '#ec4899',
    '#eab308',
    '#06b6d4',
  ];

  const activeStreamGroupColor = useMemo(() => {
    if (!activeStream) return groupColors[0];
    // Check channel streams first
    if (activeFilter === '__CHANNELS__') return '#f97316';
    let title: string | null = null;
    for (const g of groups) {
      if (g.streams.some(s => s.id === activeStream.id)) {
        title = g.title;
        break;
      }
    }
    if (!title) return groupColors[0];
    const idx = groups.findIndex(g => g.title === title);
    return groupColors[idx >= 0 ? idx % groupColors.length : 0];
  }, [activeStream, groups, activeFilter]);

  // Auto-play first stream when data loads
  useEffect(() => {
    if (groups.length > 0 && !activeStream && !loading && !error) {
      setActiveFilter('__ALL__');
      const firstStream = groups[0]?.streams[0];
      if (firstStream) {
        handleStreamClick(firstStream);
      }
    }
  }, [groups, loading, error]); // eslint-disable-line react-hooks/exhaustive-deps

  // Scroll filter pills
  const scrollFilters = (direction: 'left' | 'right') => {
    if (filterScrollRef.current) {
      const scrollAmount = 200;
      filterScrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  // Marquee
  const marqueeItems = [
    'CRICKET', 'FOOTBALL', 'TENNIS', 'BASKETBALL', 'F1 RACING',
    'MMA / UFC', 'BOXING', 'IPL 2026', 'PREMIER LEAGUE', 'NBA',
    'ABD STREAMS', 'LIVE NOW',
  ];

  const marqueeTrackRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const track = marqueeTrackRef.current;
    if (!track) return;
    let offset = 0;
    const speed = 40;
    let lastTime: number | null = null;
    let rafId: number;

    const measure = () => {
      const firstThird = Math.ceil(track.children.length / 3);
      let w = 0;
      for (let i = 0; i < firstThird; i++) {
        w += track.children[i].getBoundingClientRect().width;
      }
      return w > 0 ? w : 800;
    };
    const singleSetWidth = measure();

    const step = (now: number) => {
      if (lastTime === null) lastTime = now;
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      offset += speed * dt;
      if (offset >= singleSetWidth) offset -= singleSetWidth;
      track.style.transform = `translateX(-${offset}px)`;
      rafId = requestAnimationFrame(step);
    };
    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, []);

  // Splash screen: wait for circle CSS animation to finish, then exit
  const [splashExiting, setSplashExiting] = useState(false);
  const circleRef = useRef<SVGCircleElement>(null);
  const exitedRef = useRef(false);

  useEffect(() => {
    const el = circleRef.current;
    if (!el) return;

    const handler = (e: AnimationEvent) => {
      if (e.animationName === 'splashCircle' && !exitedRef.current) {
        exitedRef.current = true;
        setSplashExiting(true);
      }
    };
    el.addEventListener('animationend', handler);

    // Safety fallback: if animationend never fires, exit after 3s
    const fallback = setTimeout(() => {
      if (!exitedRef.current) {
        exitedRef.current = true;
        setSplashExiting(true);
      }
    }, 3000);

    return () => {
      el.removeEventListener('animationend', handler);
      clearTimeout(fallback);
    };
  }, []);

  // Determine whether to show channels mode
  const isChannelsMode = activeFilter === '__CHANNELS__';

  return (
    <div className="h-screen overflow-hidden flex flex-col" style={{ background: '#0a0a0a' }}>

      {/* ===== FULL-SCREEN SPLASH SCREEN ===== */}
      <AnimatePresence>
        {!splashExiting && (
          <motion.div
            key="splash"
            className="fixed inset-0 z-50 flex flex-col items-center justify-center"
            style={{ background: '#0a0a0a' }}
          >
            {/* Circular icon with animated progress ring */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
              className="relative"
            >
              {/* Animated SVG ring */}
              <svg className="absolute inset-0 -m-2" width="168" height="168" viewBox="0 0 168 168" fill="none" style={{ transform: 'rotate(-90deg)' }}>
                {/* Background track */}
                <circle cx="84" cy="84" r="78" stroke="#1a1a1a" strokeWidth="4" fill="none" />
                {/* Animated progress arc — pure CSS, no duration restriction */}
                <circle
                  ref={circleRef}
                  cx="84" cy="84" r="78"
                  stroke="url(#splashGrad)"
                  strokeWidth="4"
                  strokeLinecap="round"
                  fill="none"
                  className="splash-circle"
                />
                {/* Glow filter */}
                <defs>
                  <linearGradient id="splashGrad" x1="0" y1="0" x2="168" y2="168">
                    <stop offset="0%" stopColor="#14b6e5" />
                    <stop offset="50%" stopColor="#FCBA28" />
                    <stop offset="100%" stopColor="#f97316" />
                  </linearGradient>
                  <filter id="glow">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                    <feMerge>
                      <feMergeNode in="coloredBlur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>
              </svg>
              {/* Icon image */}
              <div className="relative w-[152px] h-[152px] rounded-full border-2 border-black overflow-hidden" style={{ boxShadow: '0 0 30px rgba(252,186,40,0.15), 0 0 60px rgba(20,182,229,0.1)' }}>
                <img src="/app-icon-200.png" alt="ABD STREAMS" className="w-full h-full object-cover" />
              </div>
            </motion.div>

            {/* Title below icon */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5, ease: 'easeOut' }}
              className="text-center mt-8"
            >
              <h1 className="text-3xl sm:text-4xl font-bold tracking-[0.2em] uppercase" style={{ color: '#F9F4DA' }}>
                ABD STREAMS
              </h1>
              <div className="flex items-center justify-center gap-2 mt-2">
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#f97316' }} />
                <p className="text-xs font-bold uppercase tracking-[0.2em]" style={{ color: '#FCBA28' }}>
                  Live Streaming
                </p>
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#f97316' }} />
              </div>
            </motion.div>

            {/* Loading text */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.4 }}
              className="flex items-center gap-2 mt-8"
            >
              <Loader2 className="w-3.5 h-3.5 animate-spin" style={{ color: '#FCBA28' }} />
              <p className="text-[11px] font-bold uppercase tracking-[0.15em]" style={{ color: '#888' }}>
                Fetching streams
              </p>
            </motion.div>

            {/* Bottom sports labels */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 0.5 }}
              className="absolute bottom-8 flex gap-6 sm:gap-8"
            >
              {['CRICKET', 'FOOTBALL', 'TENNIS', 'F1', 'NBA', 'UFC'].map((sport, i) => (
                <span
                  key={sport}
                  className="text-[9px] font-bold uppercase tracking-[0.2em]"
                  style={{ color: '#333' }}
                >
                  {sport}
                </span>
              ))}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== SPLASH EXIT ANIMATION (zoom + fade overlay) ===== */}
      <AnimatePresence>
        {splashExiting && (
          <motion.div
            key="splash-exit"
            initial={{ opacity: 1 }}
            animate={{ opacity: 0, scale: 1.15 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center pointer-events-none"
            style={{ background: '#0a0a0a' }}
          >
            {/* Icon zooms in during exit */}
            <motion.div
              initial={{ scale: 1, opacity: 1 }}
              animate={{ scale: 2.5, opacity: 0 }}
              transition={{ duration: 0.6, ease: 'easeInOut' }}
              className="relative w-[152px] h-[152px] rounded-full border-2 border-black overflow-hidden"
            >
              <img src="/app-icon-200.png" alt="" className="w-full h-full object-cover" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== RETROUI NAVBAR ===== */}
      <header className="relative z-10 border-b-2 border-black" style={{ background: '#0a0a0a' }}>
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* App icon in header */}
            <div className="relative w-10 h-10 rounded-lg border-2 border-black overflow-hidden flex-shrink-0" style={{ boxShadow: '3px 3px 0px #FCBA28' }}>
              <img src="/app-icon-80.png" alt="ABD STREAMS" className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-widest uppercase leading-none" style={{ color: '#F9F4DA' }}>
                ABD STREAMS
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#f97316' }} />
                <p className="text-[10px] font-bold uppercase tracking-[0.15em]" style={{ color: '#d4cfa8' }}>
                  Live Streaming
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="group relative">
              <div className="absolute inset-0 border-2 border-black transition-transform duration-300 group-hover:translate-x-[-2px] group-hover:translate-y-[-2px]" style={{ background: '#14b6e5' }} />
              <button
                onClick={fetchStreams}
                disabled={loading}
                className="relative flex items-center gap-2 px-5 py-2.5 border-2 border-black font-bold text-sm uppercase tracking-widest transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                style={{ background: '#F9F4DA', color: '#1a1a1a' }}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* ===== RETROUI MARQUEE TICKER ===== */}
      <div className="relative z-10 border-b-2 border-black overflow-hidden py-2" style={{ background: '#fcba28' }}>
        <div ref={marqueeTrackRef} className="flex whitespace-nowrap will-change-transform">
          {[...marqueeItems, ...marqueeItems, ...marqueeItems].map((item, i) => (
            <span key={i} className="inline-flex items-center gap-3 mx-5 shrink-0">
              <span className="text-[11px] font-bold uppercase tracking-[0.15em]" style={{ color: '#1a1a1a' }}>
                {item}
              </span>
              <span className="text-[8px]" style={{ color: '#1a1a1a' }}>&#9670;</span>
            </span>
          ))}
        </div>
      </div>

      {/* ===== MAIN CONTENT ===== */}
      <main className="relative z-10 flex-1 min-h-0 max-w-[1600px] mx-auto w-full px-4 sm:px-6 py-3">
        <div className="flex flex-col lg:flex-row gap-3 lg:gap-5 min-h-0 h-full">

          {/* ===== LEFT: PLAYER ===== */}
          <div className="w-full shrink-0 lg:w-[60%] xl:w-[60%] lg:min-w-0 lg:flex lg:flex-col lg:min-h-0 lg:overflow-hidden">
            <div className="lg:flex lg:flex-col lg:flex-1 lg:min-h-0">
              {activeStream ? (
                <motion.div
                  key={`player-${activeStream.id}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.2 }}
                  className="lg:flex lg:flex-col lg:flex-1 lg:min-h-0"
                >
                  <div className="relative lg:flex lg:flex-col lg:flex-1 lg:min-h-0">
                    {/* Shadow layer */}
                    <div className="absolute inset-0 border-2 border-black" style={{ background: activeStreamGroupColor, transform: 'translate(8px, 8px)', zIndex: 0 }} />
                    {/* Main player container */}
                    <div className="relative border-2 border-black overflow-hidden lg:flex lg:flex-col lg:flex-1 lg:min-h-0" style={{ background: '#0a0a0a', zIndex: 1 }}>

                      {/* Player header bar */}
                      <div className="flex items-center justify-between px-4 py-2.5 border-b-2 border-black" style={{ background: activeStreamGroupColor }}>
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1 border-2 border-black text-[9px] font-bold uppercase tracking-widest" style={{ background: '#F9F4DA', color: '#1a1a1a', boxShadow: '2px 2px 0px #000' }}>
                            <Flame className="w-2.5 h-2.5" /> Live
                          </span>
                          <span className="text-sm font-bold text-white truncate">
                            {activeStream.label}
                          </span>
                          <span className="hidden sm:inline-block px-2 py-0.5 border-2 border-black text-[8px] font-bold uppercase tracking-widest" style={{ background: '#f97316', color: '#1a1a1a', boxShadow: '2px 2px 0px #000' }}>
                            HD
                          </span>
                        </div>
                        <button
                          onClick={closePlayer}
                          className="shrink-0 w-7 h-7 border-2 border-black flex items-center justify-center transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5"
                          style={{ background: '#F9F4DA', color: '#1a1a1a', boxShadow: '2px 2px 0px #000' }}
                        >
                          <X className="w-3.5 h-3.5" strokeWidth={2.5} />
                        </button>
                      </div>

                      {/* Player area */}
                      <div className="overflow-hidden aspect-video lg:aspect-auto lg:flex-1 lg:min-h-0">
                        <CustomPlayer
                          ref={playerRef}
                          key={`stream-${activeStream.url.length}-${activeStream.id}`}
                          url={activeStream.url}
                          type={activeStream.type}
                          drmScheme={activeStream.drmScheme}
                          kid={activeStream.kid}
                          drmKey={activeStream.key}
                          title={activeStream.label}
                          useProxy={getStreamUseProxy(activeStream)}
                          onError={handlePlayerError}
                        />
                      </div>

                      {/* Error bar */}
                      {playerError && (
                        <div className="px-4 py-2.5 border-t-2 border-black flex items-center gap-2" style={{ background: '#f33' }}>
                          <AlertCircle className="w-4 h-4 shrink-0 text-white" />
                          <p className="text-xs font-bold text-white">{playerError}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="relative">
                  <div className="absolute inset-0 border-2 border-black" style={{ background: '#FCBA28', transform: 'translate(8px, 8px)', zIndex: 0 }} />
                  <div className="relative border-2 border-black flex flex-col items-center justify-center py-24 lg:py-32 gap-4" style={{ background: '#1a1a1a', zIndex: 1 }}>
                    <div className="w-16 h-16 border-2 border-black flex items-center justify-center" style={{ background: '#1a1a1a', boxShadow: '4px 4px 0px #000' }}>
                      <MonitorPlay className="w-7 h-7" style={{ color: '#F9F4DA' }} strokeWidth={1.5} />
                    </div>
                    <div className="text-center">
                      <p className="text-base font-bold uppercase tracking-widest" style={{ color: '#F9F4DA' }}>
                        Select a stream
                      </p>
                      <p className="text-xs mt-1 font-medium" style={{ color: '#888' }}>
                        Pick any link from the list to start watching
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ===== RIGHT: STREAMS LIST ===== */}
          <div className="w-full lg:w-[40%] xl:w-[40%] min-w-0 min-h-0 flex-1 overflow-y-auto overflow-x-hidden retro-scrollbar">

            {/* Filter pills with scroll arrows */}
            {!loading && groups.length > 0 && (
              <div className="sticky top-0 z-10 flex items-center gap-1.5 mb-4 pb-2 pt-1 -mx-1 px-1" style={{ background: '#0a0a0a' }}>
                {/* Left arrow */}
                <button
                  onClick={() => scrollFilters('left')}
                  className="shrink-0 w-7 h-7 border-2 border-black flex items-center justify-center transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5"
                  style={{ background: '#2a2a2a', color: '#F9F4DA', boxShadow: '2px 2px 0px #000' }}
                >
                  <ChevronRight className="w-3.5 h-3.5" style={{ transform: 'rotate(180deg)' }} />
                </button>

                {/* Scrollable pills */}
                <div
                  ref={filterScrollRef}
                  className="flex gap-2 overflow-x-auto pb-1 flex-1 [&::-webkit-scrollbar]:hidden"
                  style={{ scrollbarWidth: 'none' }}
                >
                  {/* ALL pill */}
                  <div className="group relative shrink-0">
                    <div className="absolute inset-0 border-2 border-black transition-transform duration-300 group-hover:translate-x-[-2px] group-hover:translate-y-[-2px]" style={{ background: activeFilter === '__ALL__' ? activeStreamGroupColor : '#555' }} />
                    <button
                      onClick={() => { setActiveFilter('__ALL__'); setActiveChannelSource(null); }}
                      className="relative px-4 py-2 font-bold text-xs uppercase tracking-widest border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                      style={activeFilter === '__ALL__'
                        ? { background: activeStreamGroupColor, color: '#F9F4DA' }
                        : { background: '#2a2a2a', color: '#F9F4DA' }
                      }
                    >
                      ALL
                    </button>
                  </div>
                  {/* Group pills */}
                  {groups.map((group) => {
                    const isActive = activeFilter === group.title;
                    const color = groupColors[groups.indexOf(group) % groupColors.length];
                    return (
                      <div key={group.title} className="group relative shrink-0">
                        <div className="absolute inset-0 border-2 border-black transition-transform duration-300 group-hover:translate-x-[-2px] group-hover:translate-y-[-2px]" style={{ background: isActive ? color : '#555' }} />
                        <button
                          onClick={() => { setActiveFilter(group.title); setActiveChannelSource(null); }}
                          className="relative px-4 py-2 font-bold text-xs uppercase tracking-widest border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                          style={isActive
                            ? { background: color, color: '#F9F4DA' }
                            : { background: '#2a2a2a', color: '#F9F4DA' }
                          }
                        >
                          {group.title}
                        </button>
                      </div>
                    );
                  })}
                  {/* CHANNELS pill */}
                  {channelSources.length > 0 && (
                    <div className="group relative shrink-0">
                      <div className="absolute inset-0 border-2 border-black transition-transform duration-300 group-hover:translate-x-[-2px] group-hover:translate-y-[-2px]" style={{ background: isChannelsMode ? '#f97316' : '#555' }} />
                      <button
                        onClick={() => { setActiveFilter('__CHANNELS__'); setActiveChannelSource(null); }}
                        className="relative flex items-center gap-1.5 px-4 py-2 font-bold text-xs uppercase tracking-widest border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                        style={isChannelsMode
                          ? { background: '#f97316', color: '#F9F4DA' }
                          : { background: '#2a2a2a', color: '#F9F4DA' }
                        }
                      >
                        <Tv className="w-3 h-3" />
                        Channels
                      </button>
                    </div>
                  )}
                </div>

                {/* Right arrow */}
                <button
                  onClick={() => scrollFilters('right')}
                  className="shrink-0 w-7 h-7 border-2 border-black flex items-center justify-center transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5"
                  style={{ background: '#2a2a2a', color: '#F9F4DA', boxShadow: '2px 2px 0px #000' }}
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Loading state */}
            {loading && (
              <div className="flex flex-col items-center justify-center py-20 gap-4">
                <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FCBA28' }} />
                <p className="text-sm font-bold uppercase tracking-widest" style={{ color: '#F9F4DA' }}>Loading streams</p>
              </div>
            )}

            {/* Error state */}
            {!loading && error && (
              <div className="relative">
                <div className="absolute inset-0 border-2 border-black" style={{ background: '#f33', transform: 'translate(8px, 8px)', zIndex: 0 }} />
                <div className="relative border-2 border-black p-6 flex flex-col items-center gap-4" style={{ background: '#2a2a2a', zIndex: 1 }}>
                  <div className="w-12 h-12 border-2 border-black flex items-center justify-center" style={{ background: '#f33', boxShadow: '4px 4px 0px #000' }}>
                    <AlertCircle className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold" style={{ color: '#F9F4DA' }}>{error}</p>
                    <p className="text-[10px] mt-1 uppercase tracking-widest font-medium" style={{ color: '#888' }}>Something went wrong</p>
                  </div>
                  <div className="group relative">
                    <div className="absolute inset-0 border-2 border-black transition-transform duration-300 group-hover:translate-x-[-2px] group-hover:translate-y-[-2px]" style={{ background: '#14b6e5' }} />
                    <button
                      onClick={fetchStreams}
                      className="relative flex items-center gap-2 px-5 py-2.5 font-bold text-sm uppercase tracking-widest border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                      style={{ background: '#2a2a2a', color: '#F9F4DA' }}
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Try Again
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Empty state */}
            {!loading && !error && groups.length === 0 && (
              <div className="relative">
                <div className="absolute inset-0 border-2 border-black" style={{ background: '#f97316', transform: 'translate(8px, 8px)', zIndex: 0 }} />
                <div className="relative border-2 border-black p-6 flex flex-col items-center gap-4" style={{ background: '#2a2a2a', zIndex: 1 }}>
                  <div className="w-12 h-12 border-2 border-black flex items-center justify-center" style={{ background: '#e8e8e8', boxShadow: '4px 4px 0px #000' }}>
                    <Radio className="w-6 h-6" style={{ color: '#888' }} />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold uppercase" style={{ color: '#F9F4DA' }}>No streams available</p>
                    <p className="text-[10px] mt-1 uppercase tracking-widest font-medium" style={{ color: '#888' }}>Check back later</p>
                  </div>
                  <button
                    onClick={fetchStreams}
                    className="flex items-center gap-2 px-5 py-2.5 border-2 border-black font-bold text-sm uppercase tracking-widest transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none"
                    style={{ background: '#2a2a2a', color: '#F9F4DA', boxShadow: '4px 4px 0px #000' }}
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Check Again
                  </button>
                </div>
              </div>
            )}

            {/* ===== CHANNELS MODE ===== */}
            {!loading && groups.length > 0 && isChannelsMode && (
              <div className="space-y-3 pb-6">
                <AnimatePresence mode="wait">
                  {/* Channel cards view (no channel selected yet) */}
                  {!activeChannelSource && (
                    <motion.div
                      key="channel-cards"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                    >
                      {/* Channel section header */}
                      <div className="flex items-center gap-3 mb-4 mt-1">
                        <div className="h-px flex-1" style={{ background: '#333' }} />
                        <span className="text-[10px] font-bold uppercase tracking-widest px-2 flex items-center gap-1.5" style={{ color: '#f97316' }}>
                          <Tv className="w-3 h-3" />
                          Browse Channels
                        </span>
                        <div className="h-px flex-1" style={{ background: '#333' }} />
                      </div>

                      {/* Channel cards grid */}
                      {channelSourcesLoading ? (
                        <div className="flex flex-col items-center justify-center py-12 gap-3">
                          <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#f97316' }} />
                          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: '#F9F4DA' }}>Loading channels</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {channelSources.map((channel, idx) => {
                            return (
                              <motion.button
                                key={channel.id}
                                whileTap={{ scale: 0.97 }}
                                onClick={() => handleChannelClick(channel)}
                                className="group w-full flex items-center gap-3 px-4 py-3 border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none text-left"
                                style={{ background: '#2a2a2a', color: '#F9F4DA', boxShadow: '4px 4px 0px #f97316' }}
                              >
                                {/* TV icon */}
                                <div className="shrink-0 w-9 h-9 flex items-center justify-center border-2 border-black"
                                  style={{ background: '#f97316', boxShadow: '2px 2px 0px #000' }}
                                >
                                  <Tv className="w-4 h-4" style={{ color: '#F9F4DA' }} />
                                </div>

                                {/* Channel info */}
                                <div className="flex-1 min-w-0">
                                  <span className="text-sm font-bold block uppercase tracking-wide" style={{ color: '#F9F4DA' }}>
                                    {channel.title}
                                  </span>
                                </div>

                                <ChevronRight className="w-4 h-4 shrink-0" style={{ color: '#888' }} />
                              </motion.button>
                            );
                          })}
                        </div>
                      )}
                    </motion.div>
                  )}

                  {/* Channel streams view (a channel is selected) */}
                  {activeChannelSource && (
                    <motion.div
                      key="channel-streams"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.2 }}
                    >
                      {/* Back button */}
                      <motion.button
                        whileTap={{ scale: 0.97 }}
                        onClick={handleBackToChannels}
                        className="group flex items-center gap-2 px-4 py-2 border-2 border-black font-bold text-xs uppercase tracking-widest mb-4 transition-all duration-200 hover:-translate-y-0.5 active:translate-x-1 active:translate-y-2 active:shadow-none"
                        style={{ background: '#2a2a2a', color: '#F9F4DA', boxShadow: '3px 3px 0px #f97316' }}
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        Back to Channels
                      </motion.button>

                      {/* Channel title divider */}
                      <div className="flex items-center gap-3 mb-3 mt-1">
                        <div className="h-px flex-1" style={{ background: '#333' }} />
                        <span className="text-[10px] font-bold uppercase tracking-widest px-2 flex items-center gap-1.5" style={{ color: '#f97316' }}>
                          <Tv className="w-3 h-3" />
                          {activeChannelSource.title}
                        </span>
                        <div className="h-px flex-1" style={{ background: '#333' }} />
                      </div>

                      {/* Channel streams loading state */}
                      {channelStreamsLoading && (
                        <div className="flex flex-col items-center justify-center py-12 gap-3">
                          <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#f97316' }} />
                          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: '#F9F4DA' }}>Loading streams</p>
                        </div>
                      )}

                      {/* Channel streams list */}
                      {!channelStreamsLoading && channelStreams.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {channelStreams.map((stream) => {
                            const isActive = activeId === stream.id;
                            const accentColor = '#f97316';

                            return (
                              <motion.button
                                key={stream.id}
                                whileTap={{ scale: 0.97 }}
                                onClick={() => handleStreamClick(stream)}
                                className="group w-full flex items-center gap-3 px-4 py-3 border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none text-left"
                                style={isActive
                                  ? { background: accentColor, color: '#F9F4DA', boxShadow: '4px 4px 0px #000' }
                                  : { background: '#2a2a2a', color: '#F9F4DA', boxShadow: `4px 4px 0px ${accentColor}33` }
                                }
                              >
                                {/* Play/Active icon */}
                                <div className="shrink-0 w-9 h-9 flex items-center justify-center border-2 border-black"
                                  style={isActive
                                    ? { background: '#F9F4DA', boxShadow: '2px 2px 0px #000' }
                                    : { background: '#555', boxShadow: '2px 2px 0px #000' }
                                  }
                                >
                                  {isActive ? (
                                    <span className="relative flex h-2.5 w-2.5">
                                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-40" style={{ background: '#1a1a1a' }} />
                                      <span className="relative inline-flex rounded-full h-2.5 w-2.5" style={{ background: '#1a1a1a' }} />
                                    </span>
                                  ) : (
                                    <Play className="w-3.5 h-3.5 ml-0.5 transition-colors" style={{ color: '#F9F4DA' }} />
                                  )}
                                </div>

                                {/* Label + badges */}
                                <div className="flex-1 min-w-0">
                                  <span className="text-sm font-bold block transition-colors">
                                    {stream.label}
                                  </span>
                                  <div className="flex items-center gap-1.5 mt-1">
                                    <span className="px-2 py-0.5 border-2 border-black text-[7px] font-bold uppercase tracking-widest" style={{ background: isActive ? accentColor : '#f97316', color: '#1a1a1a', boxShadow: '1px 1px 0px #000' }}>
                                      HD
                                    </span>
                                    {stream.drmScheme && (
                                      <span className="px-2 py-0.5 border-2 border-black text-[7px] font-bold uppercase tracking-widest" style={{ background: isActive ? '#F9F4DA' : '#14b6e5', color: '#1a1a1a', boxShadow: '1px 1px 0px #000' }}>
                                        Secured
                                      </span>
                                    )}
                                  </div>
                                </div>

                                <ChevronRight className="w-4 h-4 shrink-0" style={{ color: isActive ? '#F9F4DA' : '#888' }} />
                              </motion.button>
                            );
                          })}
                        </div>
                      )}

                      {/* No streams in channel */}
                      {!channelStreamsLoading && channelStreams.length === 0 && (
                        <div className="relative">
                          <div className="absolute inset-0 border-2 border-black" style={{ background: '#f97316', transform: 'translate(6px, 6px)', zIndex: 0 }} />
                          <div className="relative border-2 border-black p-5 flex flex-col items-center gap-3" style={{ background: '#2a2a2a', zIndex: 1 }}>
                            <div className="w-10 h-10 border-2 border-black flex items-center justify-center" style={{ background: '#e8e8e8', boxShadow: '3px 3px 0px #000' }}>
                              <Radio className="w-5 h-5" style={{ color: '#888' }} />
                            </div>
                            <div className="text-center">
                              <p className="text-xs font-bold uppercase" style={{ color: '#F9F4DA' }}>No streams found</p>
                              <p className="text-[9px] mt-0.5 uppercase tracking-widest font-medium" style={{ color: '#888' }}>This channel may be offline</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* ===== REGULAR STREAM LIST (non-channels mode) ===== */}
            {!loading && groups.length > 0 && !isChannelsMode && (
              <div className="space-y-3 pb-6">
                <AnimatePresence>
                  {groups
                    .filter((group) => activeFilter === '__ALL__' || group.title === activeFilter)
                    .map((group, gi) => (
                    <motion.div
                      key={group.title}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: gi * 0.05, duration: 0.2 }}
                    >
                      {/* Divider-style group header (only in ALL mode) */}
                      {activeFilter === '__ALL__' && (
                        <div className="flex items-center gap-3 mb-2 mt-1">
                          <div className="h-px flex-1" style={{ background: '#333' }} />
                          <span className="text-[10px] font-bold uppercase tracking-widest px-2" style={{ color: groupColors[groups.indexOf(group) % groupColors.length] }}>
                            {group.title}
                          </span>
                          <div className="h-px flex-1" style={{ background: '#333' }} />
                        </div>
                      )}

                      {/* Stream cards grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {group.streams.map((stream) => {
                          const isActive = activeId === stream.id;
                          const groupIdx = groups.findIndex(g => g.title === group.title);
                          const accentColor = groupColors[groupIdx % groupColors.length];

                          return (
                            <motion.button
                              key={stream.id}
                              whileTap={{ scale: 0.97 }}
                              onClick={() => handleStreamClick(stream)}
                              className="group w-full flex items-center gap-3 px-4 py-3 border-2 border-black transition-all duration-200 hover:-translate-y-1 active:translate-x-1 active:translate-y-2 active:shadow-none text-left"
                              style={isActive
                                ? { background: accentColor, color: '#F9F4DA', boxShadow: '4px 4px 0px #000' }
                                : { background: '#2a2a2a', color: '#F9F4DA', boxShadow: `4px 4px 0px ${accentColor}33` }
                              }
                            >
                              {/* Play/Active icon */}
                              <div className="shrink-0 w-9 h-9 flex items-center justify-center border-2 border-black"
                                style={isActive
                                  ? { background: '#F9F4DA', boxShadow: '2px 2px 0px #000' }
                                  : { background: '#555', boxShadow: '2px 2px 0px #000' }
                                }
                              >
                                {isActive ? (
                                  <span className="relative flex h-2.5 w-2.5">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-40" style={{ background: '#1a1a1a' }} />
                                    <span className="relative inline-flex rounded-full h-2.5 w-2.5" style={{ background: '#1a1a1a' }} />
                                  </span>
                                ) : (
                                  <Play className="w-3.5 h-3.5 ml-0.5 transition-colors" style={{ color: '#F9F4DA' }} />
                                )}
                              </div>

                              {/* Label + badges */}
                              <div className="flex-1 min-w-0">
                                <span className="text-sm font-bold block transition-colors">
                                  {stream.label}
                                </span>
                                <div className="flex items-center gap-1.5 mt-1">
                                  <span className="px-2 py-0.5 border-2 border-black text-[7px] font-bold uppercase tracking-widest" style={{ background: isActive ? accentColor : '#f97316', color: '#1a1a1a', boxShadow: '1px 1px 0px #000' }}>
                                    HD
                                  </span>
                                  {stream.drmScheme && (
                                    <span className="px-2 py-0.5 border-2 border-black text-[7px] font-bold uppercase tracking-widest" style={{ background: isActive ? '#F9F4DA' : '#14b6e5', color: '#1a1a1a', boxShadow: '1px 1px 0px #000' }}>
                                      Secured
                                    </span>
                                  )}
                                </div>
                              </div>

                              <ChevronRight className="w-4 h-4 shrink-0" style={{ color: isActive ? '#F9F4DA' : '#888' }} />
                            </motion.button>
                          );
                        })}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
