import type { Metadata } from "next";
import Script from "next/script";
import { Geist, Geist_Mono } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// Dynamic metadata — resolves og:image URLs against the actual request domain
export async function generateMetadata(): Promise<Metadata> {
  const headersList = await headers();
  const host = headersList.get('host') || 'localhost:3000';
  const forwardedProto = headersList.get('x-forwarded-proto') || 'https';
  // Always use https for public URLs (the site is served over HTTPS externally)
  const baseUrl = `https://${host.replace(/:\d+$/, '')}`;

  return {
    metadataBase: new URL(baseUrl),
    title: "ABD STREAMS — Live Sports Streaming",
    description:
      "ABD STREAMS is your go-to destination for live sports streaming. Watch cricket, football, tennis, basketball, F1 racing, MMA, boxing, and more — all in stunning HD quality, completely free.",
    keywords:
      "ABD STREAMS,live sports streaming,cricket live,football live,tennis live,basketball live,F1 racing live,MMA live,boxing live,IPL live,Premier League live,NBA live,HD sports streams,free sports streaming",
    icons: {
      icon: "/favicon.ico",
      apple: "/apple-touch-icon.png",
    },
    openGraph: {
      title: "ABD STREAMS — Live Sports Streaming",
      description:
        "ABD STREAMS is your go-to destination for live sports streaming. Watch cricket, football, tennis, basketball, F1, MMA, boxing, and more in HD quality.",
      siteName: "ABD STREAMS",
      url: baseUrl,
      locale: "en_US",
      type: "website",
      images: [
        {
          url: `${baseUrl}/og-image.png`,
          width: 1200,
          height: 630,
          alt: "ABD STREAMS — Live Sports Streaming",
          type: "image/png",
          secureUrl: `${baseUrl}/og-image.png`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "ABD STREAMS — Live Sports Streaming",
      description:
        "Your go-to destination for live sports. Cricket, football, tennis, basketball, F1, MMA, boxing and more — all in HD.",
      images: [`${baseUrl}/og-image.png`],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Preconnect to common stream CDNs for faster initial connection */}
        <link rel="preconnect" href="https://a166aivottlinear-a.akamaihd.net" />
        <link rel="preconnect" href="https://t.me" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground overflow-hidden`}
      >
        <Script src="/shaka/shaka-player.ui.min.js" strategy="beforeInteractive" />
        {children}
        <Toaster />
      </body>
    </html>
  );
}
