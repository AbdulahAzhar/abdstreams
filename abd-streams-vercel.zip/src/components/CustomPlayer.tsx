'use client';

import {
  useState,
  useEffect,
  useRef,
  useCallback,
  forwardRef,
  useImperativeHandle,
} from 'react';
import { Wifi, WifiOff, Signal } from 'lucide-react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Volume1,
  Settings,
  Maximize,
  Minimize,
  PictureInPicture2,
  Circle,
  Square,
  Download,
} from 'lucide-react';

declare global {
  interface Window {
    shaka: any;
  }
}

interface CustomPlayerProps {
  url: string;
  type: 'dash' | 'hls';
  drmScheme?: string;
  kid?: string;
  drmKey?: string;
  title: string;
  useProxy?: boolean;
  onError?: (error: string) => void;
}

export interface CustomPlayerHandle {
  getPlayer: () => any;
  destroy: () => void;
}

const CustomPlayer = forwardRef<CustomPlayerHandle, CustomPlayerProps>(
  ({ url, type, drmScheme, kid, drmKey, title, useProxy = false, onError }, ref) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const playerRef = useRef<any>(null);
    const initLockRef = useRef(false);
    const isPlayingRef = useRef(false);
    const mountedRef = useRef(true);
    const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // CORS proxy helper — uses public CORS proxy for streams that block direct browser access
    const getProxiedUrl = useCallback((streamUrl: string) => {
      return `https://api.allorigins.win/raw?url=${encodeURIComponent(streamUrl)}`;
    }, []);

    // Track whether we're using proxy (for error recovery fallback)
    const usingProxyRef = useRef(false);
    // Store the useProxy prop in a ref so error recovery respects it
    const useProxyPropRef = useRef(useProxy);
    // Generation counter — increments on each stream switch to suppress stale error events
    const generationRef = useRef(0);
    // Timer to delay error display (absorbs false errors during stream switching)
    const errorTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // Network state
    const [networkType, setNetworkType] = useState<string>('unknown');
    const [networkSpeed, setNetworkSpeed] = useState<number>(0);

    // Player state
    const [isPlaying, setIsPlaying] = useState(false);
    const [isBuffering, setIsBuffering] = useState(false);
    const [initialLoad, setInitialLoad] = useState(true);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const [initError, setInitError] = useState<string | null>(null);
    const [showVolumeSlider, setShowVolumeSlider] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [qualityTracks, setQualityTracks] = useState<any[]>([]);
    const [activeQuality, setActiveQuality] = useState<string>('Auto');

    // Helper: format quality label from a track — uses resolution (720p) if available,
    // otherwise falls back to bandwidth (2.6 Mbps) for manifests that omit resolution.
    const formatQualityLabel = useCallback((track: any): string => {
      const h = track.video?.height || track.width || 0;
      if (h > 0) return `${h}p`;
      const bw = track.bandwidth;
      if (bw > 0) return `${(bw / 1000000).toFixed(1)} Mbps`;
      return 'Auto';
    }, []);
    const [playbackRate, setPlaybackRate] = useState(1);
    const [abrEnabled, setAbrEnabled] = useState(true);
    const [settingsPanel, setSettingsPanel] = useState<'main' | 'quality' | 'speed'>('main');
    const [retrying, setRetrying] = useState(false);
    const [retryAttempt, setRetryAttempt] = useState(0);
    const retryAttemptRef = useRef(0);
    const stallDetectorRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const lastPlayTimeRef = useRef<number>(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [bufferedEnd, setBufferedEnd] = useState(0);
    const [isSeeking, setIsSeeking] = useState(false);
    const [seekRangeStart, setSeekRangeStart] = useState(0);
    const [seekRangeEnd, setSeekRangeEnd] = useState(0);
    const [isLive, setIsLive] = useState(false);
    const progressBarRef = useRef<HTMLDivElement>(null);
    const settingsRef = useRef<HTMLDivElement>(null);
    const seekStartRef = useRef(0);
    const seekEndRef = useRef(0);

    // Recording state
    const [isRecording, setIsRecording] = useState(false);
    const [recordDuration, setRecordDuration] = useState(0);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordChunksRef = useRef<Blob[]>([]);
    const recordTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const recordStartRef = useRef<number>(0);

    const destroyPlayer = useCallback(() => {
      // Immediately pause and mute the video to cut audio instantly
      if (videoRef.current) {
        videoRef.current.pause();
        videoRef.current.muted = true;
        videoRef.current.removeAttribute('src');
        videoRef.current.load();
      }
      // Destroy Shaka player
      if (playerRef.current) {
        try { playerRef.current.destroy(); } catch {}
        playerRef.current = null;
      }
      mountedRef.current = false;
      initLockRef.current = false;
    }, []);

    useImperativeHandle(ref, () => ({
      getPlayer: () => playerRef.current,
      destroy: destroyPlayer,
    }));

    const reportError = useCallback(
      (msg: string, gen: number) => {
        if (!mountedRef.current) return;
        // Cancel any pending error display
        if (errorTimerRef.current) {
          clearTimeout(errorTimerRef.current);
          errorTimerRef.current = null;
        }
        // Delay showing the error by 1.5 seconds. If the user switches streams
        // before the timer fires, the generation check will suppress it.
        const capturedGen = gen;
        errorTimerRef.current = setTimeout(() => {
          errorTimerRef.current = null;
          // Only show if we're still on the same stream (generation hasn't changed)
          if (mountedRef.current && generationRef.current === capturedGen) {
            setInitError(msg);
            onError?.(msg);
          }
        }, 1500);
      },
      [onError]
    );

    // Auto-hide controls (paused when settings open so quality panel stays visible)
    const resetHideTimer = useCallback(() => {
      setShowControls(true);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      // Don't auto-hide while settings panel is open
      if (isPlaying && !showSettings) {
        hideTimerRef.current = setTimeout(() => {
          if (mountedRef.current) setShowControls(false);
        }, 3000);
      }
    }, [isPlaying, showSettings]);

    useEffect(() => {
      return () => {
        if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
        if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
        if (touchTimeoutRef.current) clearTimeout(touchTimeoutRef.current);
      };
    }, []);

    // Auto-hide controls when playback starts or resumes
    useEffect(() => {
      if (isPlaying) {
        resetHideTimer();
      }
    }, [isPlaying, resetHideTimer]);

    // Network request filter for proxied streams — rewrite ALL segment/manifest URLs through CORS proxy.
    // When a manifest is loaded via CORS proxy, Shaka resolves relative segment URLs against
    // the proxy domain. Absolute CDN URLs in the manifest also need proxying (CDN may lack CORS).
    // This filter catches ALL requests and routes them through the CORS proxy.
    const CORS_PROXY_BASE = 'https://api.allorigins.win/raw?url=';
    const setupNetworkFilters = useCallback((player: any, manifestUrl: string) => {
      try {
        const netEngine = player.getNetworkingEngine();
        if (!netEngine) return;

        // Extract the CDN URL from the proxy URL using regex
        const urlMatch = manifestUrl.match(/[?&]url=([^&]+)/);
        const rawCdnUrl = urlMatch ? decodeURIComponent(urlMatch[1]) : '';
        if (!rawCdnUrl) return;

        // Extract CDN origin (protocol + host) for identifying CDN requests
        let cdnOrigin = '';
        try {
          const parsed = new URL(rawCdnUrl);
          cdnOrigin = parsed.origin.toLowerCase();
        } catch {}

        netEngine.registerRequestFilter((_type: any, request: any) => {
          for (let i = 0; i < request.uris.length; i++) {
            const uri = request.uris[i];

            // Already proxied — skip
            if (uri.includes('allorigins.win')) continue;

            // Skip data/blob URIs
            if (uri.startsWith('data:') || uri.startsWith('blob:')) continue;

            // Rewrite requests resolved against proxy domain back to CDN via proxy
            if (uri.includes('allorigins') || uri.includes('localhost')) {
              try {
                const parsed = new URL(uri);
                const pathAndQuery = parsed.pathname + parsed.search;
                if (pathAndQuery && pathAndQuery !== '/') {
                  const cdnBase = rawCdnUrl.substring(0, rawCdnUrl.lastIndexOf('/') + 1);
                  const cdnUrl = cdnBase + pathAndQuery.substring(1);
                  request.uris[i] = CORS_PROXY_BASE + encodeURIComponent(cdnUrl);
                }
              } catch {}
              continue;
            }

            // Rewrite absolute CDN URLs (manifest uses full CDN URLs for segments)
            if (cdnOrigin && uri.toLowerCase().startsWith(cdnOrigin)) {
              request.uris[i] = CORS_PROXY_BASE + encodeURIComponent(uri);
              continue;
            }
          }
        });

        console.log('Network filters installed for proxy mode, CDN origin:', cdnOrigin);
      } catch (e) {
        console.error('Failed to setup network filters:', e);
      }
    }, []);

    // Initialize Shaka Player
    useEffect(() => {
      // Increment generation IMMEDIATELY — before any async work starts.
      // This ensures stale errors from the old player (fired during destroy)
      // are always caught by the generation check in the error handler.
      generationRef.current++;
      const thisGeneration = generationRef.current;

      mountedRef.current = true;

      // Clear any pending error display and error state when switching streams
      if (errorTimerRef.current) {
        clearTimeout(errorTimerRef.current);
        errorTimerRef.current = null;
      }
      setInitError(null);
      setRetrying(false);
      retryAttemptRef.current = 0;

      if (initLockRef.current) return;
      initLockRef.current = true;

      const init = async () => {
        if (!videoRef.current) {
          initLockRef.current = false;
          return;
        }

        let retries = 0;
        while (!window.shaka && retries < 50) {
          await new Promise((r) => setTimeout(r, 100));
          retries++;
        }

        if (!window.shaka) {
          reportError('Stream is currently offline. Try again later.', thisGeneration);
          initLockRef.current = false;
          return;
        }

        const shaka = window.shaka;

        try {
          shaka.polyfill.installAll();
          if (!shaka.Player.isBrowserSupported()) {
            reportError('This browser cannot play the stream. Try Chrome or Firefox.', thisGeneration);
            initLockRef.current = false;
            return;
          }

          if (!mountedRef.current) {
            initLockRef.current = false;
            return;
          }

          const player = new shaka.Player();
          await player.attach(videoRef.current);
          playerRef.current = player;

          // Fix WILLOW 30-second delay: Shaka's default bufferingGoal is 30s.
          // Set aggressive low values so playback starts in ~1-2 seconds.
          try {
            player.configure('streaming.bufferingGoal', 2);
            player.configure('streaming.rebufferingGoal', 0.5);
            player.configure('streaming.startAtSegmentBoundary', false);
            player.configure('streaming.lowLatencyMode', true);
          } catch (e) {
            // If any config fails, at least set bufferingGoal
            try { player.configure('streaming.bufferingGoal', 2); } catch {}
          }

          // Determine proxy mode from prop
          // useProxy=true: stream always goes through CORS proxy (e.g. UK needs CORS proxy)
          // useProxy=false: stream loads directly from CDN (e.g. KAYO, STAN — no proxy needed)
          usingProxyRef.current = useProxy;
          const initialUrl = useProxy ? getProxiedUrl(url) : url;

          // Setup network filters only for proxied DASH streams (rewrite relative segment URLs).
          // HLS streams: the proxy's rewriteHlsManifest() rewrites all URLs server-side,
          // so Shaka receives /api/proxy?url=... URLs directly — no client-side filter needed.
          if (useProxy && type === 'dash') {
            setupNetworkFilters(player, initialUrl);
          }

          // DRM config
          // When manifests declare Widevine/PlayReady but we only have ClearKey keys,
          // Shaka may try Widevine first (fail, no license server), then fall back.
          // Setting preferredKeySystems to ClearKey avoids the delay/failure.
          if (drmScheme && kid && drmKey) {
            player.configure({
              drm: {
                clearKeys: {
                  [kid]: drmKey,
                },
                preferredKeySystems: ['org.w3.clearkey'],
              },
            });
          }

          // Detect network conditions for UI display only
          const nav = navigator as any;
          const conn = nav.connection || nav.mozConnection || nav.webkitConnection;
          if (conn && mountedRef.current) {
            setNetworkType(conn.effectiveType || conn.type || 'unknown');
            setNetworkSpeed(conn.downlink || 0);
          }

          // Listen for ABR quality changes
          player.addEventListener('adaptation', () => {
            if (!mountedRef.current) return;
            try {
              const tracks = player.getVariantTracks();
              const active = tracks.find((t: any) => t.active);
              if (active) {
                setActiveQuality(formatQualityLabel(active));
              }
            } catch {}
          });

          // Error handling with auto-recovery and user-friendly messages
          player.addEventListener('error', async (event: any) => {
            // Ignore errors from a previous stream (stale events after switching)
            if (generationRef.current !== thisGeneration) return;
            const detail = event.detail;
            const code = detail?.code || 0;
            console.error('Player error:', code, detail);

            // All user-facing messages are generic — no technical terms or error codes
            const userMessages: Record<number, string> = {
              1001: 'Stream temporarily unavailable. Retrying...',
              1002: 'Connection issue. Check your network and retry.',
              3014: 'Stream format not supported.',
              3016: 'Stream request failed. Retrying...',
              3017: 'Stream data could not be read.',
              3018: 'Stream setup failed. Try another stream.',
              4034: 'Stream is geo-blocked in your region.',
              4035: 'Stream segment missing. Retrying...',
              4038: 'Stream access denied. Retrying...',
              6006: 'Decryption failed. Stream key may have changed.',
              7000: 'Stream interrupted. Reconnecting...',
              7001: 'Stream operation aborted. Retrying...',
              7002: 'Player failed to initialize.',
              7003: 'Player was closed.',
              7004: 'Stream not loaded yet.',
            };
            const userErrMsg = userMessages[code] || 'Stream is currently offline. Try again later.';

            // Auto-recover from common transient errors
            const recoverableCodes = [1001, 1002, 3016, 4034, 4035, 4038, 7000, 7001, 3014, 3015, 3017, 3018];
            if (recoverableCodes.includes(code) && retryAttemptRef.current < 5 && mountedRef.current && generationRef.current === thisGeneration) {
              const attempt = retryAttemptRef.current + 1;
              setRetryAttempt(attempt);
              retryAttemptRef.current = attempt;
              setRetrying(true);
              setInitError(null); // Clear any previous error
              console.log(`Auto-recovering from error ${code}, attempt ${attempt}/5...`);

              // Wait with exponential backoff before retrying
              const delay = Math.min(attempt * 2000, 10000);
              await new Promise((r) => setTimeout(r, delay));

              if (!mountedRef.current || !playerRef.current) return;

              try {
                // Destroy current player and create fresh one
                const oldPlayer = playerRef.current;
                playerRef.current = null;
                await oldPlayer.destroy();

                // Smart fallback: if direct mode failed, switch to proxy for retries
                const originalUseProxy = useProxyPropRef.current;
                const switchToProxy = !originalUseProxy && attempt >= 1;
                const useProxy = switchToProxy || originalUseProxy;
                const loadUrl = useProxy ? getProxiedUrl(url) : url;

                console.log(`Retry ${attempt}/5 — ${useProxy ? 'proxy' : 'direct'} mode${switchToProxy ? ' (fallback)' : ''}...`);
                usingProxyRef.current = useProxy;

                const newPlayer = new shaka.Player();
                await newPlayer.attach(videoRef.current!);
                playerRef.current = playerRef.current || newPlayer;
                try {
                  newPlayer.configure('streaming.bufferingGoal', 2);
                  newPlayer.configure('streaming.rebufferingGoal', 0.5);
                  newPlayer.configure('streaming.startAtSegmentBoundary', false);
                  newPlayer.configure('streaming.lowLatencyMode', true);
                } catch (e) {
                  try { newPlayer.configure('streaming.bufferingGoal', 2); } catch {}
                }

                // Setup network filters for proxied DASH
                if (useProxy && type === 'dash') setupNetworkFilters(newPlayer, loadUrl);
                // For proxied HLS, server-side rewriting handles URLs

                // Re-apply DRM
                if (drmScheme && kid && drmKey) {
                  newPlayer.configure({
                    drm: {
                      clearKeys: { [kid]: drmKey },
                      preferredKeySystems: ['org.w3.clearkey'],
                    },
                  });
                }

                // Re-attach event listeners
                newPlayer.addEventListener('adaptation', () => {
                  if (!mountedRef.current) return;
                  try {
                    const tracks = newPlayer.getVariantTracks();
                    const active = tracks.find((t: any) => t.active);
                    if (active) {
                      setActiveQuality(formatQualityLabel(active));
                    }
                  } catch {}
                });

                await newPlayer.load(loadUrl);
                playerRef.current = newPlayer;

                // Seek to live edge after recovery too
                try {
                  if (typeof newPlayer.seekToLiveEdge === 'function') newPlayer.seekToLiveEdge();
                  const timeline = newPlayer.getManifest()?.presentationTimeline;
                  if (timeline && videoRef.current) videoRef.current.currentTime = timeline.getSeekRangeEnd();
                } catch {}

                // Explicitly resume playback after recovery
                if (videoRef.current) {
                  videoRef.current.play().catch(() => {
                    // If autoplay blocked, try muted then restore
                    if (videoRef.current) {
                      const vol = videoRef.current.volume;
                      videoRef.current.muted = true;
                      videoRef.current.play().then(() => {
                        setTimeout(() => {
                          if (videoRef.current && vol > 0) {
                            videoRef.current.muted = false;
                            videoRef.current.volume = vol;
                          }
                        }, 300);
                      }).catch(() => {});
                    }
                  });
                }

                // Reset retry counter on success
                setRetryAttempt(0);
                retryAttemptRef.current = 0;
                setRetrying(false);
                setIsBuffering(false);
                console.log(`Recovery successful on attempt ${attempt}`);
              } catch (retryError: any) {
                console.error(`Recovery attempt ${attempt} failed:`, retryError);
                if (attempt >= 5) {
                  setRetrying(false);
                  reportError('Stream is currently offline. Try again later.', thisGeneration);
                }
              }
            } else if (retryAttempt >= 5) {
              setRetrying(false);
              reportError('Stream is currently offline. Try again later.', thisGeneration);
            } else {
              reportError(userErrMsg, thisGeneration);
            }
          });

          player.addEventListener('loading', () => {
            if (mountedRef.current) { setIsBuffering(true); setInitialLoad(true); }
          });

          player.addEventListener('loaded', () => {
            if (mountedRef.current) setInitialLoad(false);
          });

          // Buffering events - show spinner during rebuffering
          player.addEventListener('buffering', (event: any) => {
            if (!mountedRef.current) return;
            const buffering = event.buffering;
            setIsBuffering(buffering);
            if (!buffering) setInitialLoad(false);
          });

          // Network change — only update UI display (ABR handles itself)
          if (conn) {
            const handleNetworkChange = () => {
              if (!mountedRef.current) return;
              setNetworkType(conn.effectiveType || conn.type || 'unknown');
              setNetworkSpeed(conn.downlink || 0);
            };
            conn.addEventListener('change', handleNetworkChange);
          }

          // Load with timeout — if player.load() hangs (DRM failure, network issue),
          // we need to surface an error instead of silently hanging forever.
          let loadTimedOut = false;
          const loadTimeout = setTimeout(() => {
            loadTimedOut = true;
            console.warn('player.load() timed out after 20s');
          }, 20000);

          try {
            await player.load(initialUrl);
          } catch (loadErr: any) {
            clearTimeout(loadTimeout);
            if (loadTimedOut || !mountedRef.current) {
              console.error('Load failed:', loadErr?.message || loadErr);
              reportError('Stream failed to load. Try another stream.', thisGeneration);
              initLockRef.current = false;
              return;
            }
            throw loadErr; // re-throw for outer catch
          }
          clearTimeout(loadTimeout);

          // Jump to live edge immediately
          try {
            const isLiveStream = player.isLive();
            if (isLiveStream) {
              if (typeof player.seekToLiveEdge === 'function') {
                player.seekToLiveEdge();
              }
              const timeline = player.getManifest()?.presentationTimeline;
              if (timeline && videoRef.current) {
                const liveEdge = timeline.getSeekRangeEnd();
                videoRef.current.currentTime = liveEdge;
              }
            }
          } catch (e) {
            // Non-critical
          }

          // Explicit autoplay — browser blocks autoPlay attribute on unmuted video
          try {
            const playPromise = videoRef.current.play();
            if (playPromise !== undefined) {
              playPromise.catch(async () => {
                // Autoplay blocked — try muted play then restore volume
                if (videoRef.current) {
                  const savedVolume = videoRef.current.volume;
                  videoRef.current.muted = true;
                  try {
                    await videoRef.current.play();
                    // Restore volume after a short delay
                    if (videoRef.current && savedVolume > 0) {
                      setTimeout(() => {
                        if (videoRef.current) {
                          videoRef.current.muted = false;
                          videoRef.current.volume = savedVolume;
                        }
                      }, 300);
                    }
                  } catch {}
                }
              });
            }
          } catch {}

          // Initial load timeout: if still in initial loading state after 15s,
          // show an error so the user knows something is wrong (DRM failure, dead stream, etc.)
          const initTimeout = setTimeout(() => {
            if (mountedRef.current && generationRef.current === thisGeneration) {
              // Only error if still stuck in initial load
              const video = videoRef.current;
              if (video && video.readyState < 2 && isPlayingRef.current === false) {
                console.warn('Initial load timeout — stream stuck after 15s');
                reportError('Stream is not responding. Try another stream or refresh.', thisGeneration);
              }
            }
          }, 15000);

          // Clear the timeout once playback starts
          const onFirstPlay = () => {
            clearTimeout(initTimeout);
            isPlayingRef.current = true;
          };
          const video = videoRef.current;
          if (video) {
            video.addEventListener('playing', onFirstPlay, { once: true });
            video.addEventListener('error', onFirstPlay, { once: true });
          }

          initLockRef.current = false;
        } catch (error: any) {
          console.error('Init error:', error);
          // Don't report errors from a previous stream (user already switched)
          if (generationRef.current !== thisGeneration) return;
          reportError('Stream is currently offline. Try again later.', thisGeneration);
          initLockRef.current = false;
        }
      };

      init();

      return () => {
        mountedRef.current = false;
        initLockRef.current = false;
        retryAttemptRef.current = 0;
        if (errorTimerRef.current) { clearTimeout(errorTimerRef.current); errorTimerRef.current = null; }
        if (stallDetectorRef.current) { clearInterval(stallDetectorRef.current); stallDetectorRef.current = null; }
        if (playerRef.current) {
          playerRef.current.destroy();
          playerRef.current = null;
        }
      };
    }, [url, type, drmScheme, kid, drmKey, useProxy, reportError]);

    // Stall detection — if video is "playing" but currentTime doesn't advance, the
    // stream is silently stuck. On proxy streams (Stan Sports), the throughput barely
    // exceeds the lowest bitrate, so brief stalls (5-10s) are expected. We do NOT
    // force-reload anymore because that causes a destructive cycle:
    //   reload → brief play → stall → reload → infinite buffering loop
    // Instead: if stuck for 20s with no buffer, try a gentle nudge (seek forward 0.1s)
    // to kick the MSE pipeline. Only force-reload as absolute last resort (30s stall).
    useEffect(() => {
      if (stallDetectorRef.current) { clearInterval(stallDetectorRef.current); stallDetectorRef.current = null; }
      if (!isPlaying || !playerRef.current) return;

      const video = videoRef.current;
      if (!video) return;

      lastPlayTimeRef.current = video.currentTime;
      let stuckCount = 0;
      let nudged = false;

      stallDetectorRef.current = setInterval(() => {
        if (!mountedRef.current || !videoRef.current || !playerRef.current) {
          if (stallDetectorRef.current) { clearInterval(stallDetectorRef.current); stallDetectorRef.current = null; }
          return;
        }
        const cur = videoRef.current.currentTime;
        if (Math.abs(cur - lastPlayTimeRef.current) < 0.1) {
          stuckCount++;

          // At 20s: try gentle nudge to unstick MSE pipeline
          if (stuckCount >= 20 && !nudged) {
            nudged = true;
            console.warn('Stream stuck for 20s, attempting gentle nudge...');
            try {
              const v = videoRef.current;
              if (v) {
                // Pause and resume to kick the decoder
                v.pause();
                setTimeout(() => {
                  if (v && mountedRef.current) {
                    v.currentTime = cur + 0.1;
                    v.play().catch(() => {});
                  }
                }, 100);
              }
            } catch {}
          }

          // At 30s AND no buffer: absolute last resort, force reload
          if (stuckCount >= 30) {
            const bufLen = videoRef.current?.buffered.length || 0;
            const hasBuffer = bufLen > 0 && (videoRef.current.buffered.end(bufLen - 1) - cur) > 1;
            if (!hasBuffer) {
              console.warn('Stream stall detected (30s, no buffer, nudge failed), forcing reload...');
              stuckCount = 0;
              nudged = false;
              setIsBuffering(true);
              forceReload();
            }
          }
        } else {
          stuckCount = 0;
          nudged = false;
          lastPlayTimeRef.current = cur;
        }
      }, 1000);

      return () => {
        if (stallDetectorRef.current) { clearInterval(stallDetectorRef.current); stallDetectorRef.current = null; }
      };
    }, [isPlaying]); // eslint-disable-line react-hooks/exhaustive-deps

    // Force reload the current stream (re-create player)
    const forceReload = useCallback(async () => {
      if (!mountedRef.current || !videoRef.current) return;
      const player = playerRef.current;
      if (!player) return;

      setRetrying(true);
      try {
        const shaka = window.shaka;
        if (!shaka) return;

        const oldPlayer = player;
        playerRef.current = null;
        try { await oldPlayer.destroy(); } catch {}

        const newPlayer = new shaka.Player();
        await newPlayer.attach(videoRef.current);
        playerRef.current = newPlayer;
        try {
          newPlayer.configure('streaming.bufferingGoal', 2);
          newPlayer.configure('streaming.rebufferingGoal', 0.5);
          newPlayer.configure('streaming.startAtSegmentBoundary', false);
          newPlayer.configure('streaming.lowLatencyMode', true);
        } catch (e) {
          try { newPlayer.configure('streaming.bufferingGoal', 2); } catch {}
        }

        const useProxy = usingProxyRef.current;
        const loadUrl = useProxy ? getProxiedUrl(url) : url;
        if (useProxy && type === 'dash') setupNetworkFilters(newPlayer, loadUrl);

        if (drmScheme && kid && drmKey) {
          newPlayer.configure({
            drm: {
              clearKeys: { [kid]: drmKey },
              preferredKeySystems: ['org.w3.clearkey'],
            },
          });
        }

        newPlayer.addEventListener('adaptation', () => {
          if (!mountedRef.current) return;
          try {
            const tracks = newPlayer.getVariantTracks();
            const active = tracks.find((t: any) => t.active);
            if (active) { setActiveQuality(formatQualityLabel(active)); }
          } catch {}
        });

        await newPlayer.load(loadUrl);

        try {
          if (typeof newPlayer.seekToLiveEdge === 'function') newPlayer.seekToLiveEdge();
          const tl = newPlayer.getManifest()?.presentationTimeline;
          if (tl && videoRef.current) videoRef.current.currentTime = tl.getSeekRangeEnd();
        } catch {}

        if (videoRef.current) {
          videoRef.current.play().catch(() => {
            if (videoRef.current) { videoRef.current.muted = true; videoRef.current.play().catch(() => {}); }
          });
        }

        setRetrying(false);
        setIsBuffering(false);
        console.log('Force reload complete');
      } catch (err) {
        console.error('Force reload failed:', err);
        setRetrying(false);
        reportError('Stream went offline. Please select the stream again.', generationRef.current);
      }
    }, [url, drmScheme, kid, drmKey, reportError]);

    // Video event listeners
    useEffect(() => {
      const video = videoRef.current;
      if (!video) return;

      const onPlay = () => { setIsPlaying(true); setIsBuffering(false); setInitialLoad(false); lastPlayTimeRef.current = video.currentTime; resetHideTimer(); };
      const onPause = () => { setIsPlaying(false); resetHideTimer(); };
      const onWaiting = () => { if (mountedRef.current) setIsBuffering(true); };
      const onCanPlay = () => { if (mountedRef.current) { setIsBuffering(false); setInitialLoad(false); } };
      const onPlaying = () => { if (mountedRef.current) { setIsBuffering(false); setInitialLoad(false); setIsPlaying(true); lastPlayTimeRef.current = video.currentTime; } };
      const onVolumeChange = () => {
        if (mountedRef.current) { setVolume(video.volume); setIsMuted(video.muted); }
      };
      const onTimeUpdate = () => {
        if (mountedRef.current && !isSeeking) {
          setCurrentTime(video.currentTime);
          if (video.buffered.length > 0) {
            setBufferedEnd(video.buffered.end(video.buffered.length - 1));
          }
        }
      };
      const onDurationChange = () => {
        if (mountedRef.current) setDuration(video.duration);
      };
      const onLoadedMetadata = () => {
        if (mountedRef.current) {
          setDuration(video.duration);
          if (video.buffered.length > 0) {
            setBufferedEnd(video.buffered.end(video.buffered.length - 1));
          }
          // Check if live and update seek range
          if (playerRef.current) {
            try {
              const live = playerRef.current.isLive();
              setIsLive(live);
              if (live) {
                const timeline = playerRef.current.getManifest().presentationTimeline;
                seekStartRef.current = timeline.getSeekRangeStart();
                seekEndRef.current = timeline.getSeekRangeEnd();
                setSeekRangeStart(seekStartRef.current);
                setSeekRangeEnd(seekEndRef.current);
              }
            } catch {}
          }
        }
      };

      video.addEventListener('play', onPlay);
      video.addEventListener('pause', onPause);
      video.addEventListener('waiting', onWaiting);
      video.addEventListener('canplay', onCanPlay);
      video.addEventListener('playing', onPlaying);
      video.addEventListener('volumechange', onVolumeChange);
      video.addEventListener('timeupdate', onTimeUpdate);
      video.addEventListener('durationchange', onDurationChange);
      video.addEventListener('loadedmetadata', onLoadedMetadata);

      return () => {
        video.removeEventListener('play', onPlay);
        video.removeEventListener('pause', onPause);
        video.removeEventListener('waiting', onWaiting);
        video.removeEventListener('canplay', onCanPlay);
        video.removeEventListener('playing', onPlaying);
        video.removeEventListener('volumechange', onVolumeChange);
        video.removeEventListener('timeupdate', onTimeUpdate);
        video.removeEventListener('durationchange', onDurationChange);
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
      };
    }, [resetHideTimer]);

    // Seek on progress bar click
    const handleProgressSeek = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
      const bar = progressBarRef.current;
      const video = videoRef.current;
      if (!bar || !video) return;

      const rect = bar.getBoundingClientRect();
      const clickX = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      const fraction = clickX / rect.width;

      if (isLive) {
        // For live streams, seek within the seek range (uses cached refs)
        const start = seekStartRef.current;
        const end = seekEndRef.current;
        if (end > start) {
          const seekTime = start + fraction * (end - start);
          video.currentTime = seekTime;
          setCurrentTime(seekTime);
        }
      } else if (isFinite(video.duration) && video.duration > 0) {
        // For VOD, seek normally
        const seekTime = fraction * video.duration;
        video.currentTime = seekTime;
        setCurrentTime(seekTime);
      }
    }, [isLive]);

    // Format time helper
    const formatTime = useCallback((seconds: number): string => {
      if (!isFinite(seconds) || seconds < 0) return '0:00';
      const h = Math.floor(seconds / 3600);
      const m = Math.floor((seconds % 3600) / 60);
      const s = Math.floor(seconds % 60);
      if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
      return `${m}:${s.toString().padStart(2, '0')}`;
    }, []);

    // Format live delay — shows how far behind live edge the viewer is (e.g. "5s", "1m 30s")
    const formatLiveDelay = useCallback((seconds: number): string => {
      if (!isFinite(seconds) || seconds < 0) return '';
      const s = Math.floor(seconds);
      if (s <= 2) return ''; // Essentially at live edge
      if (s < 60) return `${s}s`;
      const m = Math.floor(s / 60);
      const remS = s % 60;
      if (m < 60) return remS > 0 ? `${m}m ${remS}s` : `${m}m`;
      const h = Math.floor(m / 60);
      const remM = m % 60;
      return `${h}h ${remM}m`;
    }, []);

    // Calculate buffer fraction for seekbar
    const getBufferFraction = useCallback((): number => {
      if (isLive) {
        const start = seekStartRef.current;
        const end = seekEndRef.current;
        const range = end - start;
        if (range > 0) return Math.max(0, Math.min(1, (bufferedEnd - start) / range));
        return 0;
      }
      if (isFinite(duration) && duration > 0) {
        return Math.max(0, Math.min(1, bufferedEnd / duration));
      }
      return 0;
    }, [bufferedEnd, duration, isLive]);

    // Calculate progress fraction (uses cached refs to avoid getManifest spam)
    const getProgressFraction = useCallback((): number => {
      if (isLive) {
        const start = seekStartRef.current;
        const end = seekEndRef.current;
        const range = end - start;
        if (range > 0) return Math.max(0, Math.min(1, (currentTime - start) / range));
        return 1;
      }
      if (isFinite(duration) && duration > 0) {
        return Math.max(0, Math.min(1, currentTime / duration));
      }
      return 0;
    }, [currentTime, duration, isLive]);

    // Check live edge periodically (low frequency to avoid getManifest warnings)
    useEffect(() => {
      if (!isPlaying || !playerRef.current) return;
      const check = () => {
        if (!mountedRef.current || !playerRef.current) return;
        try {
          const live = playerRef.current.isLive();
          setIsLive(live);
          if (live) {
            const timeline = playerRef.current.getManifest()?.presentationTimeline;
            if (timeline) {
              const start = timeline.getSeekRangeStart();
              const end = timeline.getSeekRangeEnd();
              seekStartRef.current = start;
              seekEndRef.current = end;
              setSeekRangeStart(start);
              setSeekRangeEnd(end);
            }
          }
        } catch {}
      };
      // Check immediately, then every 3 seconds for responsive live-delay display
      check();
      const interval = setInterval(check, 3000);
      return () => clearInterval(interval);
    }, [isPlaying]);

    // Fullscreen change listener — handles exit via browser back/swipe/escape too
    useEffect(() => {
      const handleFsChange = () => {
        if (mountedRef.current) setIsFullscreen(!!document.fullscreenElement);
        if (!document.fullscreenElement) {
          // Exiting fullscreen — restore aspect ratio + unlock orientation
          if (containerRef.current) {
            containerRef.current.style.aspectRatio = '16/9';
          }
          try { screen.orientation?.unlock(); } catch {}
        }
      };
      document.addEventListener('fullscreenchange', handleFsChange);
      return () => document.removeEventListener('fullscreenchange', handleFsChange);
    }, []);

    // Network polling
    useEffect(() => {
      const nav = navigator as any;
      const conn = nav.connection || nav.mozConnection || nav.webkitConnection;
      if (!conn) return;
      const handle = () => {
        if (mountedRef.current) {
          setNetworkType(conn.effectiveType || conn.type || 'unknown');
          setNetworkSpeed(conn.downlink || 0);
        }
      };
      conn.addEventListener('change', handle);
      const interval = setInterval(handle, 5000);
      return () => { conn.removeEventListener('change', handle); clearInterval(interval); };
    }, []);

    // Auto-reconnect when network comes back online
    useEffect(() => {
      const handleOnline = () => {
        if (!mountedRef.current || !playerRef.current) return;
        const video = videoRef.current;
        if (video && video.paused && !video.ended) {
          console.log('Network back online, attempting reconnect...');
          setIsBuffering(true);
          forceReload();
        }
      };
      window.addEventListener('online', handleOnline);
      return () => window.removeEventListener('online', handleOnline);
    }, [forceReload]);

    // Controls
    const togglePlay = useCallback(() => {
      const video = videoRef.current;
      if (!video) return;
      if (video.paused) { video.play().catch(() => {}); } else { video.pause(); }
    }, []);

    const toggleMute = useCallback(() => {
      const video = videoRef.current;
      if (!video) return;
      video.muted = !video.muted;
      setIsMuted(video.muted);
    }, []);

    const handleVolumeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
      const video = videoRef.current;
      if (!video) return;
      const val = parseFloat(e.target.value);
      video.volume = val;
      setVolume(val);
      if (val === 0) { video.muted = true; setIsMuted(true); }
      else if (video.muted) { video.muted = false; setIsMuted(false); }
    }, []);

    const toggleFullscreen = useCallback(async () => {
      const container = containerRef.current;
      const video = videoRef.current;
      if (!container || !video) return;

      const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);

      try {
        if (!document.fullscreenElement) {
          if (isMobile) {
            const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

            if (isIOS) {
              // iOS: container fullscreen not well-supported, must fullscreen video.
              // Safari auto-rotates to landscape natively.
              try {
                await (video as any).webkitEnterFullscreen();
              } catch {
                await video.requestFullscreen();
              }
            } else {
              // Android: fullscreen the CONTAINER so custom controls stay visible.
              // Remove aspect-ratio so it fills the screen.
              container.style.aspectRatio = '';
              await container.requestFullscreen();

              // Try to lock landscape orientation (works in PWAs, silently ignored in regular tabs).
              // Custom controls remain visible either way.
              try {
                await screen.orientation?.lock?.('landscape');
              } catch {}
            }
          } else {
            // Desktop: fullscreen the container so custom controls stay visible
            container.style.aspectRatio = '';
            await container.requestFullscreen();
          }
        } else {
          // Exit fullscreen + unlock orientation
          try { screen.orientation?.unlock?.(); } catch {}
          await document.exitFullscreen();
        }
      } catch {}
    }, []);

    // Keyboard shortcuts for the player
    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        // Ignore if user is typing in an input/textarea
        const tag = (e.target as HTMLElement).tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

        const video = videoRef.current;
        if (!video) return;

        const prevent = () => { e.preventDefault(); e.stopPropagation(); };
        const preventDefaultOnly = () => { e.preventDefault(); };

        switch (e.key) {
          case ' ':       // Space — toggle play/pause
          case 'k':
          case 'K':
            prevent();
            if (video.paused) { video.play().catch(() => {}); } else { video.pause(); }
            break;

          case 'f':
          case 'F':       // F — toggle fullscreen
            prevent();
            toggleFullscreen();
            break;

          case 'm':
          case 'M':       // M — toggle mute
            prevent();
            video.muted = !video.muted;
            setIsMuted(video.muted);
            break;

          case 'ArrowLeft':  // Seek back 10s
            preventDefaultOnly();
            video.currentTime = Math.max(0, video.currentTime - 10);
            break;

          case 'ArrowRight': // Seek forward 10s
            preventDefaultOnly();
            video.currentTime += 10;
            break;

          case 'ArrowUp':    // Volume up 10%
            preventDefaultOnly();
            video.volume = Math.min(1, video.volume + 0.1);
            setVolume(video.volume);
            if (video.muted) { video.muted = false; setIsMuted(false); }
            break;

          case 'ArrowDown':  // Volume down 10%
            preventDefaultOnly();
            video.volume = Math.max(0, video.volume - 0.1);
            setVolume(video.volume);
            break;

          case 'j':
          case 'J':       // J — rewind 10s (YouTube style)
            prevent();
            video.currentTime = Math.max(0, video.currentTime - 10);
            break;

          case 'l':
          case 'L':       // L — forward 10s (YouTube style)
            prevent();
            video.currentTime += 10;
            break;

          case 'c':
          case 'C':       // C — toggle subtitles/captions if available
            prevent();
            {
              const tracks = video.textTracks;
              if (tracks.length > 0) {
                const visibleTrack = Array.from(tracks).find((t) => t.mode === 'showing');
                tracks.forEach((t) => { t.mode = 'hidden'; });
                if (!visibleTrack) tracks[0].mode = 'showing';
              }
            }
            break;

          case 'Escape':   // Escape — exit fullscreen
            if (document.fullscreenElement) {
              prevent();
              document.exitFullscreen().catch(() => {});
            }
            break;
        }

        // Show controls on any key press
        resetHideTimer();
      };

      document.addEventListener('keydown', handleKeyDown, true);
      return () => document.removeEventListener('keydown', handleKeyDown, true);
    }, [toggleFullscreen, resetHideTimer]);

    const togglePiP = useCallback(async () => {
      const video = videoRef.current;
      if (!video) return;
      try {
        if (document.pictureInPictureElement) { await document.exitPictureInPicture(); }
        else { await video.requestPictureInPicture(); }
      } catch {}
    }, []);

    // Double click to fullscreen (desktop)
    const clickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const clickCountRef = useRef(0);

    // Touch detection — prevents mouse events from firing after touch on mobile
    const isTouchRef = useRef(false);
    const touchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const lastTapRef = useRef(0);

    const handleContainerClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
      // If this click was triggered by a touch, skip — onTouchStart already handled it
      if (isTouchRef.current) {
        isTouchRef.current = false;
        return;
      }

      // Ignore clicks on controls area
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('[data-controls]')) return;

      clickCountRef.current++;
      if (clickCountRef.current === 1) {
        clickTimerRef.current = setTimeout(() => {
          // Single click — toggle controls visibility, but keep visible if settings open
          if (showControls && !showSettings) {
            setShowControls(false);
          } else {
            resetHideTimer();
          }
          clickCountRef.current = 0;
        }, 250);
      } else if (clickCountRef.current >= 2) {
        // Double click — go fullscreen
        if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
        clickCountRef.current = 0;
        toggleFullscreen();
      }
    }, [showControls, resetHideTimer, toggleFullscreen]);

    // Touch handler — tap to toggle controls, double-tap for fullscreen
    const handleTouchStart = useCallback((e: React.TouchEvent<HTMLDivElement>) => {
      // Ignore touches on buttons/controls
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('[data-controls]')) return;

      isTouchRef.current = true;
      if (touchTimeoutRef.current) clearTimeout(touchTimeoutRef.current);
      // Keep isTouchRef true for 500ms to prevent mouseLeave from firing after touch
      touchTimeoutRef.current = setTimeout(() => { isTouchRef.current = false; }, 500);

      const now = Date.now();
      const timeSince = now - lastTapRef.current;

      if (timeSince < 300 && timeSince > 0) {
        // Double tap — fullscreen
        lastTapRef.current = 0;
        toggleFullscreen();
      } else {
        // Single tap — toggle controls
        lastTapRef.current = now;
        // Use small delay to wait for potential double tap
        setTimeout(() => {
          if (lastTapRef.current !== 0 && Date.now() - lastTapRef.current >= 280) {
            lastTapRef.current = 0;
            if (mountedRef.current) {
              if (showControls && !showSettings) {
                setShowControls(false);
                if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
              } else {
                resetHideTimer();
              }
            }
          }
        }, 300);
      }
    }, [showControls, showSettings, resetHideTimer, toggleFullscreen]);

    const handleMouseMove = useCallback(() => {
      if (isRecording) return; // Don't show controls while recording
      if (!isTouchRef.current) resetHideTimer();
    }, [resetHideTimer, isRecording]);

    const handleMouseLeave = useCallback(() => {
      if (!isTouchRef.current && isPlaying && !showSettings) {
        setShowControls(false);
      }
    }, [isPlaying, showSettings]);

    const loadQualityTracks = useCallback(async () => {
      if (!playerRef.current) return;
      try {
        const tracks = await playerRef.current.getVariantTracks();
        if (tracks && mountedRef.current) {
          setQualityTracks(tracks);
          const active = tracks.find((t: any) => t.active);
          if (active) {
            setActiveQuality(formatQualityLabel(active));
          }
        }
      } catch {}
    }, []);

    const openSettings = useCallback(() => {
      if (showSettings) {
        // Already open — just close it
        setShowSettings(false);
        setSettingsPanel('main');
      } else {
        // Open settings — load tracks and show panel
        loadQualityTracks();
        setSettingsPanel('main');
        setShowSettings(true);
      }
    }, [loadQualityTracks, showSettings]);

    const closeSettings = useCallback(() => {
      setShowSettings(false);
      setSettingsPanel('main');
    }, []);

    useEffect(() => {
      const handleClick = (e: MouseEvent) => {
        // Don't close if clicking inside the settings panel OR on the settings gear button
        if (settingsRef.current && !settingsRef.current.contains(e.target as Node)) {
          const gearBtn = (e.target as HTMLElement).closest('button[title="Settings"]');
          if (!gearBtn) closeSettings();
        }
      };
      if (showSettings) {
        document.addEventListener('mousedown', handleClick);
        return () => document.removeEventListener('mousedown', handleClick);
      }
    }, [showSettings, closeSettings]);

    const selectQuality = useCallback(async (track: any) => {
      if (!playerRef.current) return;
      try {
        if (!track) {
          playerRef.current.configure({ abr: { enabled: true } });
          setAbrEnabled(true);
          // Don't override activeQuality — let adaptation events keep it showing the current quality
          // so the Auto button displays "Auto (1080p)" etc.
        } else {
          playerRef.current.configure({ abr: { enabled: false } });
          setAbrEnabled(false);
          await playerRef.current.selectVariantTrack(track);
          setActiveQuality(formatQualityLabel(track));
        }
      } catch (e) { console.error('Quality switch error:', e); }
    }, []);

    const changePlaybackRate = useCallback((rate: number) => {
      const video = videoRef.current;
      if (!video) return;
      video.playbackRate = rate;
      setPlaybackRate(rate);
    }, []);

    // Toggle recording — captures only the player using getDisplayMedia + canvas crop
    const displayStreamRef = useRef<MediaStream | null>(null);
    const cropCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const cropVideoRef = useRef<HTMLVideoElement | null>(null);
    const cropAnimRef = useRef<number | null>(null);

    const cleanupRecording = useCallback(() => {
      document.body.style.overflow = '';
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      if (recordTimerRef.current) { clearInterval(recordTimerRef.current); recordTimerRef.current = null; }
      if (cropAnimRef.current) { cancelAnimationFrame(cropAnimRef.current); cropAnimRef.current = null; }
      if (cropVideoRef.current) { cropVideoRef.current.srcObject = null; cropVideoRef.current = null; }
      if (cropCanvasRef.current) { cropCanvasRef.current.remove(); cropCanvasRef.current = null; }
      if (displayStreamRef.current) { displayStreamRef.current.getTracks().forEach(t => t.stop()); displayStreamRef.current = null; }
    }, []);

    const toggleRecording = useCallback(async () => {
      if (isRecording) {
        cleanupRecording();
        document.body.style.overflow = '';
        setIsRecording(false);
      } else {
        try {
          const container = containerRef.current;
          if (!container) return;

          // Hide controls & cursor, lock scroll while recording
          setShowControls(false);
          if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
          document.body.style.overflow = 'hidden';

          // Capture current tab — cursor: 'never' hides mouse from capture
          const displayStream = await navigator.mediaDevices.getDisplayMedia({
            video: {
              displaySurface: 'browser',
              frameRate: { ideal: 30 },
              cursor: 'never',
            },
            audio: {
              echoCancellation: false,
              noiseSuppression: false,
              autoGainControl: false,
            },
            preferCurrentTab: true,
          } as any);

          displayStreamRef.current = displayStream;

          // Stop recording if user clicks "Stop sharing" in browser
          displayStream.getTracks().forEach(track => {
            track.addEventListener('ended', () => {
              cleanupRecording();
              if (mountedRef.current) setIsRecording(false);
            });
          });

          // Create a hidden video element to receive the display stream
          const cropVideo = document.createElement('video');
          cropVideo.srcObject = displayStream;
          cropVideo.muted = true;
          cropVideo.playsInline = true;
          await cropVideo.play();
          cropVideoRef.current = cropVideo;

          // Wait a frame for the video to settle after picker dismisses
          await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

          // Re-read player rect (picker may have shifted layout)
          const freshRect = container.getBoundingClientRect();

          // Wait for captured video to report real dimensions
          let waitFrames = 0;
          while (cropVideo.videoWidth === 0 && waitFrames < 30) {
            await new Promise(r => requestAnimationFrame(r));
            waitFrames++;
          }

          // Calculate scale from actual captured video dimensions (not guessed DPR)
          const vw = cropVideo.videoWidth;
          const vh = cropVideo.videoHeight;
          const scaleX = vw / window.innerWidth;
          const scaleY = vh / window.innerHeight;

          // Player region in captured video pixel coordinates
          const sx = Math.round(freshRect.left * scaleX);
          const sy = Math.round(freshRect.top * scaleY);
          const sw = Math.round(freshRect.width * scaleX);
          const sh = Math.round(freshRect.height * scaleY);

          const canvas = document.createElement('canvas');
          canvas.width = sw;
          canvas.height = sh;
          canvas.style.display = 'none';
          const ctx = canvas.getContext('2d')!;
          cropCanvasRef.current = canvas;

          // Crop loop: draw only the player region from the captured tab
          let running = true;
          const cropLoop = () => {
            if (!running || !cropVideoRef.current || !cropCanvasRef.current) return;
            const cw = cropCanvasRef.current.width;
            const ch = cropCanvasRef.current.height;
            if (cropVideoRef.current.videoWidth > 0) {
              ctx.drawImage(cropVideoRef.current, sx, sy, sw, sh, 0, 0, cw, ch);
            }
            cropAnimRef.current = requestAnimationFrame(cropLoop);
          };
          cropLoop();

          // Get a clean cropped stream from the canvas
          const croppedStream = canvas.captureStream(30);

          // Carry over audio from the display capture
          const audioTracks = displayStream.getAudioTracks();
          audioTracks.forEach(t => croppedStream.addTrack(t));

          recordChunksRef.current = [];
          const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
            ? 'video/webm;codecs=vp9,opus'
            : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
              ? 'video/webm;codecs=vp8,opus'
              : 'video/webm';

          const recorder = new MediaRecorder(croppedStream, {
            mimeType,
            videoBitsPerSecond: 5000000,
          });
          mediaRecorderRef.current = recorder;

          recorder.ondataavailable = (e) => {
            if (e.data && e.data.size > 0) {
              recordChunksRef.current.push(e.data);
            }
          };

          recorder.onstop = () => {
            running = false;
            if (recordChunksRef.current.length > 0) {
              const blob = new Blob(recordChunksRef.current, { type: mimeType });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `${title.replace(/[^a-zA-Z0-9]/g, '_')}_${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.webm`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
            recordChunksRef.current = [];
            // Full cleanup after download triggered
            if (displayStreamRef.current) { displayStreamRef.current.getTracks().forEach(t => t.stop()); displayStreamRef.current = null; }
            if (cropAnimRef.current) { cancelAnimationFrame(cropAnimRef.current); cropAnimRef.current = null; }
            if (cropVideoRef.current) { cropVideoRef.current.srcObject = null; cropVideoRef.current = null; }
            if (cropCanvasRef.current) { cropCanvasRef.current.remove(); cropCanvasRef.current = null; }
          };

          recorder.onerror = () => {
            running = false;
            cleanupRecording();
            if (mountedRef.current) setIsRecording(false);
          };

          recorder.start(1000);
          setIsRecording(true);
          setRecordDuration(0);
          recordStartRef.current = Date.now();

          recordTimerRef.current = setInterval(() => {
            if (mountedRef.current) {
              setRecordDuration(Math.floor((Date.now() - recordStartRef.current) / 1000));
            }
          }, 1000);
        } catch (err: any) {
          if (err.name !== 'AbortError' && err.name !== 'NotAllowedError') {
            console.error('Recording failed:', err);
          }
          cleanupRecording();
        }
      }
    }, [isRecording, title, cleanupRecording]);

    // Cleanup recorder on unmount
    useEffect(() => {
      return () => { cleanupRecording(); };
    }, [cleanupRecording]);

    const formatRecordTime = useCallback((seconds: number): string => {
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }, []);

    const VolumeIcon = isMuted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

    // Derive quality tier label from active quality string (e.g. "1920p" → "FHD")
    const getQualityTier = useCallback((): string => {
      const match = activeQuality.match(/(\d+)/);
      if (!match) return '';
      const h = parseInt(match[1], 10);
      if (h >= 2160) return '4K';
      if (h >= 1440) return 'QHD';
      if (h >= 1080) return 'FHD';
      if (h >= 720) return 'HD';
      if (h >= 480) return 'SD';
      return '';
    }, [activeQuality]);

    const getNetworkColor = () => {
      if (!networkType || networkType === 'unknown') return 'text-white/50';
      if (networkType === '4g') return 'text-green-400';
      if (networkType === '3g') return 'text-yellow-400';
      return 'text-red-400';
    };

    const getNetworkLabel = () => {
      if (!networkType || networkType === 'unknown') return '';
      return networkType.toUpperCase();
    };

    const NetworkIconComp = () => {
      if (!networkType || networkType === 'unknown') return <Wifi className="w-3 h-3" />;
      if (networkType === '4g') return <Wifi className="w-3 h-3" />;
      if (networkType === '3g') return <Signal className="w-3 h-3" />;
      return <WifiOff className="w-3 h-3" />;
    };

    const CheckIcon = () => (
      <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
      </svg>
    );

    const BackIcon = () => (
      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
      </svg>
    );

    const ChevronIcon = () => (
      <svg className="w-3.5 h-3.5 text-white/40" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
      </svg>
    );

    return (
      <div
        ref={containerRef}
        className={`player-container relative w-full bg-black select-none${isRecording ? ' recording-active' : ''}`}
        style={{ aspectRatio: '16/9', cursor: isRecording ? 'none' : undefined }}
        onMouseMove={handleMouseMove}
        onTouchStart={handleTouchStart}
        onMouseLeave={handleMouseLeave}
        onClick={handleContainerClick}
      >
        <video
          ref={videoRef}
          className="w-full h-full"
          autoPlay
          playsInline
          style={{ width: '100%', height: '100%', objectFit: 'contain' }}
        />

        {/* ===== BUFFERING BAR — top of player (multi-color shimmer) ===== */}
        {(isBuffering || retrying) && !initError && (
          <div className="absolute top-0 left-0 right-0 z-40 overflow-hidden h-1.5 border-b border-black">
            <div
              className="h-full w-full"
              style={{
                background: 'linear-gradient(90deg, transparent 0%, #f97316 15%, #FCBA28 30%, #ffd600 50%, #14b6e5 70%, #FCBA28 85%, #f97316 100%, transparent 100%)',
                backgroundSize: '200% 100%',
                animation: 'liveShimmer 1.5s linear infinite',
              }}
            />
          </div>
        )}

        {/* Error overlay — RetroUI style */}
        {initError && (
          <div className="absolute inset-0 flex items-center justify-center z-40" style={{ background: 'rgba(0,0,0,0.92)' }}>
            <div className="text-center px-6">
              <div className="w-14 h-14 border-2 border-black flex items-center justify-center mx-auto mb-3" style={{ background: '#ff3344', boxShadow: '4px 4px 0px #000' }}>
                <span className="text-white text-2xl font-bold">!</span>
              </div>
              <p className="text-xs font-bold uppercase tracking-wider" style={{ color: '#F9F4DA' }}>{initError}</p>
            </div>
          </div>
        )}

        {/* Controls overlay */}
        <div
          className={`absolute inset-0 z-20 transition-opacity duration-300 pointer-events-none ${
            showControls ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {/* Bottom gradient */}
          <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black/95 via-black/60 to-transparent pointer-events-none" />

          {/* Center play button — RetroUI square style */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {!isPlaying && !isBuffering && !initialLoad && (
              <div
                className="relative pointer-events-auto cursor-pointer"
                onClick={(e) => { e.stopPropagation(); togglePlay(); }}
              >
                <div className="absolute inset-0 border-2 border-black" style={{ background: '#f97316', transform: 'translate(4px, 4px)' }} />
                <div className="relative w-16 h-16 border-2 border-black flex items-center justify-center transition-all duration-200 hover:-translate-y-1 active:translate-y-1" style={{ background: '#F9F4DA' }}>
                  <Play className="w-7 h-7 ml-1" style={{ color: '#1a1a1a' }} fill="#1a1a1a" />
                </div>
              </div>
            )}
          </div>

          {/* ===== SETTINGS PANEL ===== */}
          {showSettings && (
            <div
              className="absolute bottom-24 right-4 w-56 z-50 pointer-events-auto"
              ref={settingsRef}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="border-2 border-black overflow-hidden" style={{ background: '#1a1a1a', boxShadow: '4px 4px 0px #000' }}>
                {settingsPanel === 'quality' && (
                  <>
                    <div className="flex items-center gap-2 px-3 py-2.5 border-b-2 border-black" style={{ background: '#14b6e5' }}>
                      <button onClick={() => setSettingsPanel('main')} className="text-white/80 hover:text-white transition-colors"><BackIcon /></button>
                      <span className="text-[11px] font-bold text-white uppercase tracking-widest">Quality</span>
                    </div>
                    <div className="py-1 max-h-48 overflow-y-auto">
                      <button
                        onClick={() => { selectQuality(null); closeSettings(); }}
                        className={`w-full flex items-center justify-between px-3 py-2 text-[13px] font-bold uppercase tracking-wider transition-colors ${abrEnabled ? '' : 'hover:bg-white/5'}`}
                        style={abrEnabled ? { background: '#f97316', color: '#1a1a1a' } : { color: '#888' }}
                      >
                        <span className="font-bold">Auto{abrEnabled && activeQuality !== 'Auto' ? ` (${activeQuality})` : ''}</span>
                        {abrEnabled && <div className="w-4 h-4 flex items-center justify-center" style={{ background: '#14b6e5' }}><CheckIcon /></div>}
                      </button>
                      {qualityTracks.map((track: any, idx: number) => {
                        const label = formatQualityLabel(track);
                        const bitrate = track.bandwidth ? `${Math.round(track.bandwidth / 1000)} kbps` : '';
                        const isActive = track.active && !abrEnabled;
                        return (
                          <button key={idx} onClick={() => { selectQuality(track); closeSettings(); }}
                            className={`w-full flex items-center justify-between px-3 py-2 text-[13px] font-bold uppercase tracking-wider transition-colors ${isActive ? '' : 'hover:bg-white/5'}`}
                            style={isActive ? { background: '#14b6e5', color: '#1a1a1a' } : { color: '#888' }}>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{label}</span>
                              {bitrate && <span className="text-[10px] text-white/30">{bitrate}</span>}
                            </div>
                            {isActive && <div className="w-4 h-4 flex items-center justify-center" style={{ background: '#14b6e5' }}><CheckIcon /></div>}
                          </button>
                        );
                      })}
                      {qualityTracks.length === 0 && (
                        <div className="px-3 py-3 text-center"><span className="text-xs text-white/30">Loading tracks...</span></div>
                      )}
                    </div>
                  </>
                )}

                {settingsPanel === 'speed' && (
                  <>
                    <div className="flex items-center gap-2 px-3 py-2.5 border-b-2 border-black" style={{ background: '#f97316' }}>
                      <button onClick={() => setSettingsPanel('main')} className="text-white/80 hover:text-white transition-colors"><BackIcon /></button>
                      <span className="text-[11px] font-bold text-white uppercase tracking-widest">Speed</span>
                    </div>
                    <div className="py-1">
                      {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((rate) => (
                        <button key={rate} onClick={() => { changePlaybackRate(rate); closeSettings(); }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-[13px] font-bold uppercase tracking-wider transition-colors ${playbackRate === rate ? '' : 'hover:bg-white/5'}`}
                          style={playbackRate === rate ? { background: '#f97316', color: '#1a1a1a' } : { color: '#888' }}>
                          <span className="font-bold">{rate === 1 ? 'Normal' : `${rate}x`}</span>
                          {playbackRate === rate && <div className="w-4 h-4 flex items-center justify-center" style={{ background: '#f97316' }}><CheckIcon /></div>}
                        </button>
                      ))}
                    </div>
                  </>
                )}

                {settingsPanel === 'main' && (
                  <>
                    <div className="px-3 py-2.5 border-b-2 border-black" style={{ background: '#FCBA28' }}>
                      <span className="text-[11px] font-bold uppercase tracking-widest" style={{ color: '#1a1a1a' }}>Settings</span>
                    </div>
                    <div className="py-1">
                      <button onClick={() => setSettingsPanel('quality')}
                        className="w-full flex items-center justify-between px-3 py-2.5 text-[13px] font-bold uppercase tracking-wider hover:bg-white/5 transition-colors" style={{ color: '#F9F4DA' }}>
                        <div className="flex items-center gap-2.5">
                          <svg className="w-4 h-4" style={{ color: '#14b6e5' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                            <rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" />
                          </svg>
                          <span className="font-bold">Quality</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px]" style={{ color: '#14b6e5' }}>{abrEnabled ? `Auto (${activeQuality})` : activeQuality}</span><ChevronIcon />
                        </div>
                      </button>
                      <button onClick={() => setSettingsPanel('speed')}
                        className="w-full flex items-center justify-between px-3 py-2.5 text-[13px] font-bold uppercase tracking-wider hover:bg-white/5 transition-colors" style={{ color: '#F9F4DA' }}>
                        <div className="flex items-center gap-2.5">
                          <svg className="w-4 h-4" style={{ color: '#f97316' }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          <span className="font-bold">Speed</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px]" style={{ color: '#888' }}>{playbackRate === 1 ? 'Normal' : `${playbackRate}x`}</span><ChevronIcon />
                        </div>
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* ===== BOTTOM CONTROLS — LEFT title, CENTER play controls, RIGHT utilities ===== */}
          <div
            className="absolute bottom-0 left-0 right-0 px-4 pb-4 pt-6 pointer-events-auto"
            data-controls="true"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Seekable Progress Bar with timestamps */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-[10px] text-white/60 shrink-0 w-8 text-right">
                {isLive
                  ? formatTime(currentTime - seekStartRef.current)
                  : formatTime(currentTime)}
              </span>
              <div
                ref={progressBarRef}
                className="relative flex-1 h-2 overflow-visible cursor-pointer group border border-black"
                style={{ background: '#333' }}
                onClick={handleProgressSeek}
              >
                {/* Buffered amount — real video.buffered data */}
                <div className="absolute inset-y-0 left-0" style={{ background: '#555', width: `${getBufferFraction() * 100}%` }} />
                {/* Progress fill — gradient orange */}
                <div
                  className="absolute inset-y-0 left-0 transition-[width] duration-100"
                  style={{
                    width: `${getProgressFraction() * 100}%`,
                    background: 'linear-gradient(90deg, #f97316, #fbbf24)',
                  }}
                />
                {/* Seek handle — RetroUI square */}
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 border-2 border-black opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none"
                  style={{ background: '#F9F4DA', left: `calc(${getProgressFraction() * 100}% - 6px)`, boxShadow: '2px 2px 0px #000' }}
                />
              </div>
              <span className="text-[10px] text-white/60 shrink-0 w-8">
                {isLive
                  ? formatLiveDelay(seekRangeEnd - currentTime)
                  : formatTime(duration)}
              </span>
              {/* LIVE badge — click to go to live */}
              {isLive && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    const v = videoRef.current;
                    if (!v) return;
                    try {
                      const p = playerRef.current;
                      if (p && typeof p.seekToLiveEdge === 'function') p.seekToLiveEdge();
                      const end = seekEndRef.current;
                      if (end > 0) v.currentTime = end;
                    } catch {}
                  }}
                  className="shrink-0 flex items-center gap-1 border-2 border-black px-2 py-0.5 transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0.5"
                  style={{ background: '#ff3344', boxShadow: '2px 2px 0px #000' }}
                  title="Go to Live"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  <span className="text-[9px] font-black text-white tracking-widest uppercase">Live</span>
                </button>
              )}
            </div>

            {/* Three-column layout: LEFT title, CENTER controls, RIGHT utilities */}
            <div className="flex items-center justify-between">

              {/* LEFT — Title (hidden on small screens unless fullscreen) */}
              <div className={`flex items-center gap-2 min-w-0 flex-1 ${isFullscreen ? '' : 'max-lg:hidden'}`}>
                <span className="text-white text-sm font-bold truncate drop-shadow-lg">
                  {title}
                </span>
              </div>

              {/* CENTER — Playback controls (always visible) */}
              <div className="flex items-center gap-0.5 shrink-0">
                {/* Rewind 10s */}
                <button
                  onClick={() => { const v = videoRef.current; if (v) v.currentTime = Math.max(0, v.currentTime - 10); }}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors"
                  title="Rewind 10s"
                >
                  <div className="relative w-5 h-5">
                    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                      <path d="M1 4v6h6" /><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center text-[7px] font-black text-white">10</span>
                  </div>
                </button>

                {/* Play/Pause */}
                <button onClick={togglePlay} className="w-11 h-9 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors">
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" fill="white" />
                  ) : (
                    <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
                  )}
                </button>

                {/* Forward 10s */}
                <button
                  onClick={() => { const v = videoRef.current; if (v) v.currentTime += 10; }}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors"
                  title="Forward 10s"
                >
                  <div className="relative w-5 h-5">
                    <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
                      <path d="M23 4v6h-6" /><path d="M20.49 15a9 9 0 1 1-2.13-9.36L23 10" />
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center text-[7px] font-black text-white">10</span>
                  </div>
                </button>
              </div>

              {/* RIGHT — Always visible; on small screens only volume + fullscreen */}
              <div className="flex items-center gap-0.5 shrink-0 flex-1 justify-end">
                {/* Recording timer — desktop only */}
                {isRecording && (
                  <div className={`flex items-center gap-1 mr-1 max-md:hidden`}>
                    <Circle className="w-2.5 h-2.5 text-red-500 animate-pulse" fill="currentColor" />
                    <span className="text-[10px] font-bold text-white tabular-nums">{formatRecordTime(recordDuration)}</span>
                  </div>
                )}

                {/* Volume — always visible */}
                <div
                  className="flex items-center relative"
                  onMouseEnter={() => setShowVolumeSlider(true)}
                  onMouseLeave={() => setShowVolumeSlider(false)}
                >
                  <button onClick={toggleMute} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors">
                    <VolumeIcon className="w-5 h-5 text-white" />
                  </button>
                  <div className={`flex items-center overflow-hidden transition-all duration-200 ${showVolumeSlider ? 'w-24 ml-0.5' : 'w-0 ml-0'}`}>
                    <input
                      type="range" min="0" max="1" step="0.01"
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-full h-1 appearance-none bg-white/30 rounded-full outline-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-md"
                    />
                  </div>
                </div>

                {/* Record — desktop only */}
                <button
                  onClick={(e) => { e.stopPropagation(); toggleRecording(); }}
                  className={`w-9 h-9 flex items-center justify-center border-2 transition-colors max-md:hidden ${isRecording ? 'border-black' : 'border-transparent hover:bg-white/10'}`}
                  style={isRecording ? { background: '#ff3344', boxShadow: '2px 2px 0px #000' } : {}}
                  title={isRecording ? 'Stop Recording' : 'Start Recording'}
                >
                  {isRecording ? (
                    <Square className="w-3.5 h-3.5 text-white" fill="white" />
                  ) : (
                    <Circle className="w-4 h-4 text-red-500" fill="currentColor" />
                  )}
                </button>

                {/* Settings + quality tier badge */}
                <div className={`relative flex items-center ${isFullscreen ? '' : 'max-lg:hidden'}`}>
                  <button
                    onClick={(e) => { e.stopPropagation(); openSettings(); }}
                    className={`w-9 h-9 flex items-center justify-center rounded-full transition-colors ${showSettings ? 'bg-white/20' : 'hover:bg-white/10'}`}
                    title="Settings"
                  >
                    <Settings className={`w-[18px] h-[18px] text-white transition-transform duration-200 ${showSettings ? 'rotate-90' : ''}`} />
                  </button>
                  {getQualityTier() && (
                    <span className="absolute -top-1.5 -right-2.5 text-[8px] font-black text-white/60 uppercase tracking-wider select-none leading-none">{getQualityTier()}</span>
                  )}
                </div>

                {/* PiP — hidden on small screens */}
                <button onClick={togglePiP} className={`w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors ${isFullscreen ? '' : 'max-lg:hidden'}`} title="Picture in Picture">
                  <PictureInPicture2 className="w-[18px] h-[18px] text-white" />
                </button>

                {/* Fullscreen — always visible */}
                <button onClick={toggleFullscreen} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors" title="Fullscreen">
                  {isFullscreen ? <Minimize className="w-5 h-5 text-white" /> : <Maximize className="w-5 h-5 text-white" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* CSS animation for live shimmer */}
        <style jsx global>{`
          @keyframes liveShimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
          }
        `}</style>
      </div>
    );
  }
);

CustomPlayer.displayName = 'CustomPlayer';
export default CustomPlayer;
