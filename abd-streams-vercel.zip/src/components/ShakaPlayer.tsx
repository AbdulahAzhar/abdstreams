'use client';

import { useEffect, useRef, useCallback, useState } from 'react';

declare global {
  interface Window {
    shaka: any;
  }
}

interface ShakaPlayerProps {
  url: string;
  type: 'dash' | 'hls';
  drmScheme?: string;
  kid?: string;
  drmKey?: string;
  onError?: (error: string) => void;
}

export default function ShakaPlayer({
  url,
  type,
  drmScheme,
  kid,
  drmKey,
  onError,
}: ShakaPlayerProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const errorRef = useRef<string | null>(null);
  const [initError, setInitError] = useState<string | null>(null);
  const mountedRef = useRef(true);
  const initLockRef = useRef(false);

  const reportError = useCallback(
    (msg: string) => {
      errorRef.current = msg;
      if (mountedRef.current) {
        setInitError(msg);
      }
      onError?.(msg);
    },
    [onError]
  );

  useEffect(() => {
    mountedRef.current = true;

    // Prevent duplicate initialization from strict mode or rapid switching
    if (initLockRef.current) return;
    initLockRef.current = true;

    const init = async () => {
      if (!wrapperRef.current) {
        initLockRef.current = false;
        return;
      }

      // Wait for shaka to load from local file
      let retries = 0;
      while (!window.shaka && retries < 50) {
        await new Promise((r) => setTimeout(r, 100));
        retries++;
      }

      if (!window.shaka) {
        reportError('Shaka Player failed to load. Please refresh.');
        initLockRef.current = false;
        return;
      }

      const shaka = window.shaka;

      try {
        shaka.polyfill.installAll();

        if (!shaka.Player.isBrowserSupported()) {
          reportError('Your browser is not supported by Shaka Player.');
          initLockRef.current = false;
          return;
        }

        if (!mountedRef.current) {
          initLockRef.current = false;
          return;
        }

        // Create a completely fresh DOM structure for each stream
        const wrapper = wrapperRef.current;

        // Clear any existing content
        wrapper.innerHTML = '';

        // Create fresh video element
        const video = document.createElement('video');
        video.id = 'shaka-video-' + Date.now();
        video.style.width = '100%';
        video.style.height = '100%';
        video.style.maxWidth = '100%';
        video.autoPlay = true;
        video.playsInline = true;
        video.setAttribute('data-shaka-player', '');
        wrapper.appendChild(video);

        // Create fresh container for overlay
        const container = document.createElement('div');
        container.setAttribute('data-shaka-player-container', '');
        container.style.position = 'relative';
        container.style.width = '100%';
        container.style.aspectRatio = '16/9';
        container.style.backgroundColor = '#000';
        container.appendChild(video);
        wrapper.appendChild(container);
        wrapper.style.position = 'relative';
        wrapper.style.width = '100%';
        wrapper.style.backgroundColor = '#000';

        // Initialize player
        const player = new shaka.Player();
        await player.attach(video);

        // DRM clearkey config
        if (drmScheme && kid && drmKey) {
          player.configure({
            drm: {
              clearKeys: {
                [kid]: drmKey,
              },
            },
          });
        }

        // Streaming config
        player.configure({
          streaming: {
            bufferingGoal: 30,
            rebufferingGoal: 2,
            bufferBehind: 30,
          },
          abr: {
            enabled: true,
            defaultBandwidthEstimate: 5000000,
          },
        });

        // Error listener
        const onErrorEvent = (event: any) => {
          const detail = event.detail;
          const errMsg =
            detail?.message || detail?.toString?.() || 'Unknown playback error';
          console.error('Shaka error:', detail);
          if (!errorRef.current) {
            reportError(`Playback error: ${errMsg}`);
          }
        };
        player.addEventListener('error', onErrorEvent);

        // Shaka UI overlay
        const ui = new shaka.ui.Overlay(player, container, video);
        const controls = ui.getControls();
        if (controls) {
          controls.addEventListener('error', (event: any) => {
            console.error('UI error:', event);
          });
        }

        if (!mountedRef.current) {
          // Component unmounted during init — clean up
          player.removeEventListener('error', onErrorEvent);
          ui.destroy();
          player.destroy();
          initLockRef.current = false;
          return;
        }

        // Load the stream
        await player.load(url);
        console.log('Stream loaded successfully');
        initLockRef.current = false;
      } catch (error: any) {
        console.error('Init error:', error);
        const msg =
          error?.message || error?.toString?.() || 'Failed to load stream';
        reportError(msg);
        initLockRef.current = false;
      }
    };

    init();

    return () => {
      mountedRef.current = false;
      initLockRef.current = false;
      // Clean up DOM completely on unmount
      if (wrapperRef.current) {
        wrapperRef.current.innerHTML = '';
      }
    };
  }, [url, type, drmScheme, kid, drmKey, reportError]);

  return (
    <div className="relative w-full bg-black">
      <div ref={wrapperRef} data-shaka-wrapper />
      {initError && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#FFFBF0]/95 z-50">
          <div className="text-center px-6">
            <div className="w-14 h-14 rounded-xl bg-[#FF6B6B] border-[3px] border-[#1a1a1a] shadow-[4px_4px_0px_0px_#1a1a1a] flex items-center justify-center mx-auto mb-3">
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2.5}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4.5c-.77-.833-2.694-.833-3.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"
                />
              </svg>
            </div>
            <p className="text-sm font-black text-[#1a1a1a] uppercase">
              {initError}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
